@echo off
echo ===================================================
echo     MEMBUKA APLIKASI SHOROF MULTIFUNGSI (LOKAL)
echo ===================================================
echo Memeriksa instalasi Python untuk web server...
python -m http.server 8000 >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Python tidak terdeteksi. Mencoba Node.js / npx...
    npx http-server -p 8000 >nul 2>&1
    if %ERRORLEVEL% NEQ 0 (
        echo Oh tidak! Python atau Node.js tidak tersedia.
        echo Agar Service Worker dan PWA berjalan lancar, 
        echo silakan gunakan web server lokal atau klik ganda 
        echo index.html langsung (beberapa fitur offline PWA terbatas).
        pause
        start "" "index.html"
        exit
    )
) else (
    echo Menjalankan server pada http://localhost:8000 ...
    start "" "http://localhost:8000"
    python -m http.server 8000
)
