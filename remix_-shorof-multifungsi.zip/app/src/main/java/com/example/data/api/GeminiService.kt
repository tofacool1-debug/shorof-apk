package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

// --- Gemini API Request Models ---

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @Json(name = "contents") val contents: List<Content>,
    @Json(name = "generationConfig") val generationConfig: GenerationConfig? = null,
    @Json(name = "systemInstruction") val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    @Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    @Json(name = "text") val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    @Json(name = "responseMimeType") val responseMimeType: String? = null,
    @Json(name = "responseSchema") val responseSchema: ResponseSchema? = null,
    @Json(name = "temperature") val temperature: Float? = null
)

@JsonClass(generateAdapter = true)
data class ResponseSchema(
    @Json(name = "type") val type: String,
    @Json(name = "properties") val properties: Map<String, ResponseSchema>? = null,
    @Json(name = "required") val required: List<String>? = null,
    @Json(name = "items") val items: ResponseSchema? = null,
    @Json(name = "description") val description: String? = null
)

// --- Gemini API Response Models ---

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @Json(name = "candidates") val candidates: List<Candidate>?
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @Json(name = "content") val content: Content?
)

// --- Target Structured Object for Arabic Verb Analysis ---

@JsonClass(generateAdapter = true)
data class AiVerbAnalysis(
    @Json(name = "root") val root: String,                 // e.g. "ف - ت - ح"
    @Json(name = "bab") val bab: Int,                      // e.g. 3
    @Json(name = "babPattern") val babPattern: String,     // e.g. "فَعَلَ - يَفْتَحُ"
    @Json(name = "meaning") val meaning: String,           // Indonesian meaning
    @Json(name = "transliteration") val transliteration: String,
    @Json(name = "madhi") val madhi: String,
    @Json(name = "mudhari") val mudhari: String,
    @Json(name = "masdar") val masdar: String,
    @Json(name = "fail") val fail: String,
    @Json(name = "maful") val maful: String,
    @Json(name = "amr") val amr: String,
    @Json(name = "nahy") val nahy: String,
    @Json(name = "zaman") val zaman: String,
    @Json(name = "makan") val makan: String,
    @Json(name = "alah") val alah: String?,
    @Json(name = "explanation") val explanation: String,   // Indonesian description of the verb conjugation
    
    // New Advanced Classical Fields
    @Json(name = "dictionarySources") val dictionarySources: String,     // Detailed citations of famous dictionaries (Lisan Al-Arab, Al-Wasit, Al-Muhit)
    @Json(name = "shorofType") val shorofType: String,                   // e.g. "Salim", "Mudha'af", "Ajwaf Wawiy", etc.
    @Json(name = "asalKataGhoiruSalim") val asalKataGhoiruSalim: String, // Phonological origin and transformation steps if Ghoiru Salim (or "Berjenis Salim/Shahih" if healthy)
    @Json(name = "sifatMusyabbahah") val sifatMusyabbahah: String,       // Sifat Musyabbahah forms with harokat
    @Json(name = "jamakTaksir") val jamakTaksir: String,                 // Broken plural form(s) of associated verbal nouns/descriptors
    @Json(name = "shigotMuntahalJumuk") val shigotMuntahalJumuk: String, // Ultimate broken plural format (if applicable, e.g. مَفَاعِيْل / مَفَاعِل)
    @Json(name = "multipleMasdars") val multipleMasdars: String,         // All alternative verbal nouns/masdars of this verb
    @Json(name = "isimTasghir") val isimTasghir: String,                 // Isim Tasghir with harokat
    @Json(name = "isimTafdhilMudzakkar") val isimTafdhilMudzakkar: String, // Isim Tafdhil Mudzakkar with harokat
    @Json(name = "isimTafdhilMuannats") val isimTafdhilMuannats: String  // Isim Tafdhil Muannats with harokat
)

// --- Retrofit API Interface ---

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    /**
     * Call the Gemini API server-side to analyze an arbitrary 3-letter Arabic verb root.
     */
    suspend fun analyzeVerbRoot(rootInput: String): AiVerbAnalysis {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("API Key is missing or default placeholder. Harap konfigurasi GEMINI_API_KEY Anda di Secrets panel AI Studio.")
        }

        val prompt = """
            Analyze the following Arabic word, root, or verb (supports both Mujarrad/Tsulatsi Mujarrad and Mazid/Tsulatsi Mazid/Ruba'i augmented verbs): "$rootInput" under the Arabic morphological framework (Ilmu Sharaf).
            
            Determine:
            1. Root letters (consonants) separated by hyphens (e.g., "ن - ص - ر" or "ك - ر - م" or similar).
            2. The morphological Bab/Category (Mujarrad Bab 1 to 6, or Mazid/augmented verb templates such as Bab If'aal, Taf'iil, Mufaa'alah, tafa''ul, tafaau'l, ifti'aal, infi'aal, istif'aal, etc.). If it is Mujarrad, return the Bab number (1..6). If it is Mazid, return bab = 0.
            3. Indonesian meaning.
            4. Arabic transliteration (e.g. "Abhara - Yubhiru" or "Aslama - Yuslimu").
            5. The 10 morphological forms (Tasrif Istilahy): Madhi, Mudhari', Masdar, Isim Fa'il, Isim Maf'ul, Fi'il Amr, Fi'il Nahy, Isim Zaman, Isim Makan, Isim Alah (optional). Ensure they are fully voweled with correct harokat for either Mujarrad or Mazid.
            6. A clean Indonesian morphological explanation (keterangan morfologi).
            7. Citations and definitions from famous Arabic dictionaries like Lisan al-Arab (لسان العرب), Al-Qamus al-Muhit, and Al-Mu'jam al-Wasit regarding this word.
            8. IMPORTANT: Specifically add detailed references from **Kamus Al-Munawwir (Kamus Munawwir)**, explaining the Indonesian meaning, usage, and derived forms listed in Kamus Al-Munawwir for this word or root. Put this inside the 'dictionarySources' field along with the other sources.
            9. Whether the verb is "Salim" or "Ghairu Salim" (Mithal, Ajwaf, Naqis, Mudha'af, or Mahmuz, or its Mazid equivalent).
            10. If Ghairu Salim or Mazid, explain its phonological background or vowel change (I'lal/Ibdal/Idgham) from its original form (asal kata).
            11. Sifat Musyabbahah of the verb/root (or typical adjectival forms with copyable harokat).
            12. Applicable Jamak Taksir (Broken Plural) and Shigot Muntahal Jumuk for derived nouns.
            13. Multiple alternative Masdars if the verb has more than one.
            14. The "Isim Tasghir" (Bentuk Tasghir / Diminutive) of this word or root (with copyable harokat, e.g., نُصَيْرٌ or كُتَيْبٌ).
            15. The "Isim Tafdhil Mudzakkar" (Bentuk Komparatif/Superlatif Masbukkan/Maskulin, with copyable harokat, e.g., أَنْصَرُ or أَكْتَبُ).
            16. The "Isim Tafdhil Muannats" (Bentuk Komparatif/Superlatif Feminin, with copyable harokat, e.g., نُصْرَىٰ or كُتْبَىٰ).
            
            Please reply STRICTLY in JSON format matching the schema rules, with no Markdown fences.
        """.trimIndent()

        val systemInstructionText = """
            You are a master of Arabic morphology (Ilmu Sharaf / Morfologi Arab) and a native Indonesian translator with expert access to famous Arabic lexicons and dictionaries.
            Your task is to analyze Arabic words, roots, or verbs—supporting both Mujarrad (Tsulatsi Mujarrad Bab 1-6) and Mazid (Tsulatsi Mazid with 1, 2, or 3 extra letters, e.g., Bab If'aal, Taf'iil, Mufaa'alah, Tafa''ul, etc.)—and return a highly detailed, voweled conjugation table and dictionary notes in Indonesian.
            You MUST explicitly include detailed meaning and citations from **Kamus Al-Munawwir (Kamus Munawwir)**, Lisan al-Arab (لسان العرب), and Al-Mu'jam al-Wasit under the 'dictionarySources' field.
            You must output JSON matching the following object schema exactly:
            {
              "root": "3-letter root consonants separated by hyphens (e.g. ف - ت - ح or similar)",
              "bab": integer: 1 to 6 if Mujarrad, or 0 if Mazid/Augmented,
              "babPattern": "e.g. فَعَلَ - يَفْتَحُ (Mujarrad) or أَفْعَلَ - يُفْعِلُ (Mazid/Augmented) corresponding to the verb pattern",
              "meaning": "Indonesian meaning of the verb/word",
              "transliteration": "e.g. Kataba - Yaktubu or Akrama - Yukrimu",
              "madhi": "Fi'il Madhi with full harokat",
              "mudhari": "Fi'il Mudhari with full harokat",
              "masdar": "Primary Masdar with full harokat",
              "fail": "Isim Fa'il with full harokat",
              "maful": "Isim Maf'ul with full harokat",
              "amr": "Fi'il Amr with full harokat",
              "nahy": "Fi'il Nahy with full harokat",
              "zaman": "Isim Zaman with full harokat",
              "makan": "Isim Makan with full harokat",
              "alah": "Isim Alah with full harokat (null if unused)",
              "explanation": "Clear, friendly Indonesian morphological explanation",
              "dictionarySources": "Detailed explanations and notes cited from Kamus Al-Munawwir (Kamus Munawwir) AND famous Arabic dictionaries (Lisan al-Arab, Al-Wasit, Al-Muhit) in Indonesian language",
              "shorofType": "Morphological classification: e.g., Salim, or Ghairu Salim (Ajwaf Wawiy / Naqis Ya'iy / Mithal Wawiy / Mudha'af / Mahmuz) or Mazid equivalent",
              "asalKataGhoiruSalim": "If Ghairu Salim or Mazid, explain how the word transformed physically (vowel steps/I'lal/Idgham/ziyadah) from its original base. If Salim, state that it is a healthy verb",
              "sifatMusyabbahah": "Sifat Musyabbahah forms with full harokat (e.g., حَسَنٌ / كَرِيْمٌ)",
              "jamakTaksir": "Broken plural forms (Jamak Taksir) for nouns associated with this root, with full harokat",
              "shigotMuntahalJumuk": "Broken plural of ultimate form / Shighat Muntahal Jumuk if applicable, with harokat. If not applicable, write \"-\"",
              "multipleMasdars": "All known alternative Masdar (Verbal Noun) variations with harokat, separated by commas (e.g. 'كِتَابَةً، كَتْبًا')",
              "isimTasghir": "Isim Tasghir with full harokat on pattern fu'aylun (e.g. نُصَيْرٌ / كُتَيْبٌ)",
              "isimTafdhilMudzakkar": "Isim Tafdhil Mudzakkar with full harokat on pattern af'alu (e.g. أَنْصَرُ / أَكْتَبُ)",
              "isimTafdhilMuannats": "Isim Tafdhil Muannats with full harokat on pattern fu'laa ending in alif maqsurah (e.g. نُصْرَى / كُتْبَى)"
            }
        """.trimIndent()

        // Construct properties map for JSON schema enforcement
        val stringSchema = ResponseSchema(type = "STRING")
        val intSchema = ResponseSchema(type = "INTEGER")
        
        val properties = mapOf(
            "root" to stringSchema.copy(description = "3-letter root consonants separated by hyphens (e.g. ف - ت - ح)"),
            "bab" to intSchema.copy(description = "The Bab number (1..6) representing the verb category"),
            "babPattern" to stringSchema.copy(description = "The morphological pattern (e.g. فَعَلَ - يَفْعَلُ)"),
            "meaning" to stringSchema.copy(description = "The Indonesian translation of the verb"),
            "transliteration" to stringSchema.copy(description = "Transliteration of Madhi - Mudhari (e.g. Fataha - Yaftahu)"),
            "madhi" to stringSchema.copy(description = "Fi'il Madhi (Past Tense) with full harokat"),
            "mudhari" to stringSchema.copy(description = "Fi'il Mudhari (Present Tense) with full harokat"),
            "masdar" to stringSchema.copy(description = "Primary Masdar with full harokat"),
            "fail" to stringSchema.copy(description = "Isim Fa'il with full harokat"),
            "maful" to stringSchema.copy(description = "Isim Maf'ul with full harokat"),
            "amr" to stringSchema.copy(description = "Fi'il Amr with full harokat"),
            "nahy" to stringSchema.copy(description = "Fi'il Nahy with full harokat"),
            "zaman" to stringSchema.copy(description = "Isim Zaman with full harokat"),
            "makan" to stringSchema.copy(description = "Isim Makan with full harokat"),
            "alah" to stringSchema.copy(description = "Isim Alah with full harokat (optional, can be null)"),
            "explanation" to stringSchema.copy(description = "Clear Indonesian explanation of this verb's bab and pattern"),
            "dictionarySources" to stringSchema.copy(description = "Quotes and references from Lisan Al-Arab, Al-Mu'jam Al-Wasit, Al-Qamus Al-Muhit in Indonesian"),
            "shorofType" to stringSchema.copy(description = "Shorof class e.g. Salim, Ajwaf, Naqis, Mithal, Mudha'af, Mahmuz"),
            "asalKataGhoiruSalim" to stringSchema.copy(description = "Indonesian explanation of how the original form transformed if ghairu salim"),
            "sifatMusyabbahah" to stringSchema.copy(description = "Voweled Sifat Musyabbahah forms"),
            "jamakTaksir" to stringSchema.copy(description = "Voweled broken plural forms"),
            "shigotMuntahalJumuk" to stringSchema.copy(description = "Ultimate plural formula form or '-'"),
            "multipleMasdars" to stringSchema.copy(description = "Alternative masdars separated by commas"),
            "isimTasghir" to stringSchema.copy(description = "Isim Tasghir with full harokat (e.g. نُصَيْرٌ)"),
            "isimTafdhilMudzakkar" to stringSchema.copy(description = "Isim Tafdhil Mudzakkar with full harokat (e.g. أَنْصَرُ)"),
            "isimTafdhilMuannats" to stringSchema.copy(description = "Isim Tafdhil Muannats with full harokat (e.g. نُصْرَى)")
        )

        val jsonSchema = ResponseSchema(
            type = "OBJECT",
            properties = properties,
            required = listOf(
                "root", "bab", "babPattern", "meaning", "transliteration", "madhi", "mudhari", 
                "masdar", "fail", "maful", "amr", "nahy", "zaman", "makan", "explanation",
                "dictionarySources", "shorofType", "asalKataGhoiruSalim", "sifatMusyabbahah", 
                "jamakTaksir", "shigotMuntahalJumuk", "multipleMasdars", "isimTasghir",
                "isimTafdhilMudzakkar", "isimTafdhilMuannats"
            )
        )

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText))),
            generationConfig = GenerationConfig(
                responseMimeType = "application/json",
                responseSchema = jsonSchema,
                temperature = 0.2f
            )
        )

        // Use gemini-3.1-pro-preview as primary model for complex linguistic reasoning.
        // Fallback options in case of 503 or unsupported transient errors.
        val modelsToTry = listOf(
            "gemini-3.1-pro-preview",
            "gemini-3.1-flash-lite-preview",
            "gemini-2.5-flash",
            "gemini-3.5-flash"
        )

        var lastException: Exception? = null
        for (model in modelsToTry) {
            try {
                val response = service.generateContent(model, apiKey, request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: throw IllegalStateException("AI did not return a response context.")

                // Parse JSON output using Moshi
                val adapter = moshi.adapter(AiVerbAnalysis::class.java)
                val parsedResult = adapter.fromJson(textResponse)
                if (parsedResult != null) {
                    return parsedResult
                }
            } catch (e: Exception) {
                lastException = e
                System.err.println("Gemini search with model $model failed: ${e.message}. Retrying with fallback model...")
            }
        }

        throw lastException ?: IllegalStateException("Gagal memproses hasil analisis morfologi AI dari seluruh model fallback.")
    }
}
