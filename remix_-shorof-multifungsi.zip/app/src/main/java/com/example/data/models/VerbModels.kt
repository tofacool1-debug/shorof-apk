package com.example.data.models

data class ArabicVerb(
    val id: String,
    val root: String,            // e.g. "ن - ص - ر"
    val bab: Int,               // 1..6
    val meaning: String,        // e.g. "Menolong"
    val transliteration: String, // e.g. "Nasara - Yansuru"
    
    // Tasrif Istilahiy (10 basic forms)
    val madhi: String,        // 1. Past (الفعل الماضي)
    val mudhari: String,      // 2. Present (الفعل المضارع)
    val masdar: String,       // 3. Gerund (المصدر)
    val fail: String,         // 4. Subject/Active Participle (اسم الفاعل)
    val maful: String,        // 5. Object/Passive Participle (اسم المفعول)
    val amr: String,          // 6. Imperative (فعل الأمر)
    val nahy: String,         // 7. Prohibitive (فعل النهي)
    val zaman: String,        // 8. Noun of Time (اسم الزمان)
    val makan: String,        // 9. Noun of Place (اسم المكان)
    val alah: String? = null, // 10. Instrument (اسم الآلة) - some verbs don't have it
    
    // Advanced Morphological Fields
    val dictionarySources: String? = null,   // Citations from Lisan al-Arab, Al-Mu'jam al-Wasit, etc.
    val shorofType: String? = null,          // e.g., "Salim" or "Ghairu Salim (Ajwaf / Naqis / Mithal / Mudha'af / Mahmuz)"
    val asalKataGhoiruSalim: String? = null, // Historical phonetic/morphological base explanation
    val sifatMusyabbahah: String? = null,    // Sifat Musyabbahah adjectives (especially for Bab 5 verbs)
    val jamakTaksir: String? = null,         // Broken plural forms of substantive or active nouns
    val shigotMuntahalJumuk: String? = null, // Plurals of ultimate maximum form
    val multipleMasdars: String? = null,     // Alternative multiple verbal nouns/masdars if any
    val isimTasghir: String? = null,          // Isim Tasghir with full harokat
    val isimTafdhilMudzakkar: String? = null, // Isim Tafdhil Mudzakkar with full harokat
    val isimTafdhilMuannats: String? = null  // Isim Tafdhil Muannats with full harokat
)

enum class Pronoun(val dhomir: String, val meaningIndo: String) {
    HUA("هُوَ", "Dia (1 Laki-laki)"),
    HUMA("هُمَا", "Dia Berdua (2 Laki-laki)"),
    HUM("هُمْ", "Mereka (Laki-laki Banyak)"),
    HIYA("هِيَ", "Dia (1 Perempuan)"),
    HUMA_F("هُمَا", "Dia Berdua (2 Perempuan)"),
    HUNNA("هُنَّ", "Mereka (Perempuan Banyak)"),
    ANTA("أَنْتَ", "Kamu (1 Laki-laki)"),
    ANTUMA("أَنْتُمَا", "Kamu Berdua (L/P)"),
    ANTUM("أَنْتُمْ", "Kalian (Laki-laki Banyak)"),
    ANTI("أَنْتِ", "Kamu (1 Perempuan)"),
    ANTUMA_F("أَنْتُمَا", "Kamu Berdua (L/P)"),
    ANTUNNA("أَنْتُنَّ", "Kalian (Perempuan Banyak)"),
    ANA("أَنَا", "Saya (L/P)"),
    NAHNU("نَحْنُ", "Kami/Kita (L/P)")
}

enum class TasrifType {
    MADHI, MUDHARI, AMR, NAHY, FAIL, SIFAT_MUSYABBAHAH, MAFUL, ZAMAN, MAKAN, ALAH, TASGHIR, TAFDHIL_MUDZAKKAR, TAFDHIL_MUANNATS
}

object VerbData {
    val BAB_INFO = mapOf(
        1 to BabDetails(1, "فَعَلَ - يَفْعُلُ (Fa'ala - Yaf'ulu)", "Vokal fathah pada fi'il madhi dan dhommah pada mudhari'.", "نَصَرَ - يَنْصُرُ"),
        2 to BabDetails(2, "فَعَلَ - يَفْعِلُ (Fa'ala - Yaf'ilu)", "Vokal fathah pada fi'il madhi dan kasrah pada mudhari'.", "ضَرَبَ - يَضْرِبُ"),
        3 to BabDetails(3, "فَعَلَ - يَفْعَلُ (Fa'ala - Yaf'alu)", "Vokal fathah di kedua fi'il. Mengharuskan huruf halaq (ع atau ل).", "فَتَحَ - يَفْتَحُ"),
        4 to BabDetails(4, "فَعِلَ - يَفْعَلُ (Fa'ila - Yaf'alu)", "Vokal kasrah pada fi'il madhi dan fathah pada mudhari'.", "عَلِمَ - يَعْلَمُ"),
        5 to BabDetails(5, "فَعُلَ - يَفْعُلُ (Fa'ula - Yaf'ulu)", "Vokal dhommah di kedua fi'il. Menunjukkan sifat yang melekat.", "حَسُنَ - يَحْسُنُ"),
        6 to BabDetails(6, "فَعِلَ - يَفْعِلُ (Fa'ila - Yaf'ilu)", "Vokal kasrah di kedua fi'il. Bab paling sedikit anggotanya.", "حَسِbَ - يَحْسِبُ")
    )

    data class BabDetails(
        val number: Int,
        val pattern: String,
        val description: String,
        val example: String
    )

    val verbs = listOf(
        // --- BAB 1 ---
        ArabicVerb(
            id = "b1_1", root = "ن - ص - ر", bab = 1, meaning = "Menolong", transliteration = "Nasara - Yansuru",
            madhi = "نَصَرَ", mudhari = "يَنْصُرُ", masdar = "نَصْرًا",
            fail = "نَاصِرٌ", maful = "مَنْصُوْرٌ", amr = "اُنْصُرْ", nahy = "لَا تَنْصُرْ",
            zaman = "مَنْصَرٌ", makan = "مَنْصَرٌ", alah = "مِنْصَرٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "نَصْرًا (Naṣran)",
            sifatMusyabbahah = "نَصِيْرٌ (Naṣīr)",
            jamakTaksir = "أَنْصَارٌ (Anṣār)",
            shigotMuntahalJumuk = "مَنَاصِرُ (Manāṣir)",
            isimTasghir = "نُصَيْرٌ",
            isimTafdhilMudzakkar = "أَنْصَرُ",
            isimTafdhilMuannats = "نُصْرَى",
            dictionarySources = "Lisan al-Arab (لسان العرب) & Al-Mu'jam al-Wasit:\nKata dasar 'نصر' menunjukkan pertolongan, perbantuan, kemenangan terhadap musuh. Sering dirujuk di Al-Qur'an (seperti 'إِذَا جَاءَ نَصْرُ اللَّهِ'). Jamak Taksir-nya adalah أَنْصَارٌ (Anṣār) yang merupakan nama pendukung setia Nabi di Madinah."
        ),
        ArabicVerb(
            id = "b1_2", root = "ك - ت - ب", bab = 1, meaning = "Menulis", transliteration = "Kataba - Yaktubu",
            madhi = "كَتَبَ", mudhari = "يَكْتُبُ", masdar = "كِتَابَةً",
            fail = "كَاتِبٌ", maful = "مَكْتُوْبٌ", amr = "اُكْتُبْ", nahy = "لَا تَكْتُبْ",
            zaman = "مَكْتَبٌ", makan = "مَكْتَبٌ", alah = "مِكْتَبٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "كِتَابَةً (Kitābatan) / كَتْبًا",
            sifatMusyabbahah = "كَتِيْبٌ",
            jamakTaksir = "كُتُبٌ (Kutub)",
            shigotMuntahalJumuk = "مَكَاتِيبُ (Makātīb)",
            isimTasghir = "كُتَيْبٌ",
            isimTafdhilMudzakkar = "أَكْتَبُ",
            isimTafdhilMuannats = "كُتْبَى",
            dictionarySources = "Taj al-Arus (تاج العروس):\nDari akar kata 'كتب' yang bermakna mengumpulkan lembaran, menjahit kulit, mencatat ketetapan hukum. Buku/kitab disebut كِتَابٌ dengan Jamak Taksir كُتُبٌ. Bentuk Shighat Muntahal Jumuk untuk Isim Makan/Zaman bertipe wadah adalah مَكَاتِيبُ."
        ),
        ArabicVerb(
            id = "b1_3", root = "د - خ - ل", bab = 1, meaning = "Masuk", transliteration = "Dakhala - Yadkhulu",
            madhi = "دَخَلَ", mudhari = "يَدْخُلُ", masdar = "دُخُوْلًا",
            fail = "دَاخِلٌ", maful = "مَدْخُوْلٌ", amr = "اُدْخُلْ", nahy = "لَا تَدْخُلْ",
            zaman = "مَدْخَلٌ", makan = "مَدْخَلٌ", alah = "مِدْخَلٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "دُخُوْلًا (Dukhūlan)",
            sifatMusyabbahah = "دَخِيْلٌ",
            jamakTaksir = "دَوَاخِلُ (Dawākhil)",
            shigotMuntahalJumuk = "مَدَاخِلُ (Madākhil)",
            dictionarySources = "Al-Qamus al-Muhit (القاموس المحيط):\nBermakna menyeberangi dari luar ke batas dalam. Isim Makan مَدْخَلٌ bermakna pintu masuk atau celah pintu dengan Muntahal Jumuk مَدَاخِلُ."
        ),
        ArabicVerb(
            id = "b1_4", root = "خ - r - ج", bab = 1, meaning = "Keluar", transliteration = "Kharaja - Yakhruju",
            madhi = "خَرَجَ", mudhari = "يَخْرُجُ", masdar = "خُرُوْجًا",
            fail = "خَارِجٌ", maful = "مَخْرُوْجٌ", amr = "اُخْرُجْ", nahy = "لَا تَخْرُجْ",
            zaman = "مَخْرَجٌ", makan = "مَخْرَجٌ", alah = "مِخْرَجٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "خُرُوْجًا (Khurūjan)",
            sifatMusyabbahah = "خَرِيْجٌ",
            jamakTaksir = "خَوَارِجُ (Khawārij)",
            shigotMuntahalJumuk = "مَخَارِجُ (Makhārij)",
            dictionarySources = "Maqayis al-Lughah (مقاييس اللغة):\nAkar 'خرج' menunjukkan perpindahan dari dalam ke area lapan yang luas. Tempat keluarnya vokal huruf hijaiyah disebut مَخْرَجٌ, dengan Muntahal Jumuk مَخَارِجُ Haluuf."
        ).copy(root = "خ - ر - ج"),
        ArabicVerb(
            id = "b1_5", root = "س - ج - د", bab = 1, meaning = "Sujud/Bersujud", transliteration = "Sajada - Yasjudu",
            madhi = "سَجَدَ", mudhari = "يَسْجُدُ", masdar = "سُجُوْدًا",
            fail = "سَاجِدٌ", maful = "مَسْجُوْدٌ", amr = "اُسْجُدْ", nahy = "لَا تَسْجُدْ",
            zaman = "مَسْجِدٌ", makan = "مَسْجِدٌ", alah = "مِسْجَدٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "سُجُوْدًا (Sujūdan)",
            sifatMusyabbahah = "سَجِيْدٌ",
            jamakTaksir = "سُجَّدٌ (Sujjad) / سُجُوْدٌ",
            shigotMuntahalJumuk = "مَسَاجِدُ (Masājid)",
            dictionarySources = "Lisan al-Arab (لسان العرب):\nMakna aslinya adalah tunduk, merendahkan dahi ke bumi demi ibadah kepada Sang Pencipta. Isim Makan-nya menyimpang secara sima'iy berharakat kasrah مَسْجِدٌ (Masjid - tempat sujud) dengan Muntahal Jumuk مَسَاجِدُ."
        ),

        // --- BAB 2 ---
        ArabicVerb(
            id = "b2_1", root = "ض - ر - ب", bab = 2, meaning = "Memukul", transliteration = "Daraba - Yadribu",
            madhi = "ضَرَبَ", mudhari = "يَضْرِبُ", masdar = "ضَرْبًا",
            fail = "ضَارِبٌ", maful = "مَضْرُوْبٌ", amr = "اِضْرِبْ", nahy = "لَا تَضْرِبْ",
            zaman = "مَضْرِبٌ", makan = "مَضْرِبٌ", alah = "مِضْرَبٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "ضَرْبًا (ḍarban)",
            sifatMusyabbahah = "ضَرِيْبٌ",
            jamakTaksir = "ضُرُوْبٌ (ḍurūb)",
            shigotMuntahalJumuk = "مَضَارِبُ (maḍārib)",
            dictionarySources = "Al-Sihah fi al-Lughah (الصحاح في اللغة):\nAkar 'ضرب' bermakna mengayunkan alat fisik keras ke benda lain, atau membuat perumpamaan ('ضرب المثل'). Jamak Taksir dari ضربًا adalah ضُرُوبٌ yang berarti macam-macam klasifikasi."
        ),
        ArabicVerb(
            id = "b2_2", root = "ج - ل - س", bab = 2, meaning = "Duduk", transliteration = "Jalasa - Yajlisu",
            madhi = "جَلَسَ", mudhari = "يَجْلِسُ", masdar = "جُلُوْسًا",
            fail = "جَالِسٌ", maful = "مَجْلُوْسٌ", amr = "اِجْلِسْ", nahy = "لَا تَجَلِسْ",
            zaman = "مَجْلِسٌ", makan = "مَجْلِسٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "جُلُوْسًا (Julūsan)",
            sifatMusyabbahah = "جَلِيْسٌ",
            jamakTaksir = "مَجَالِسُ (Majālis)",
            shigotMuntahalJumuk = "مَجَالِسُ (Majālis)",
            dictionarySources = "Al-Wasit:\nDari kata 'جلس' yang berarti terduduk tegak dari posisi tidur atau lantai. Tempat perkumpulan musyawarah disebut مَجْلِسٌ dengan Shighat Muntahal Jumuk مَجَالِسُ."
        ).copy(nahy = "لَا تَجْلِسْ"),
        ArabicVerb(
            id = "b2_3", root = "غ - س - ل", bab = 2, meaning = "Mencuci", transliteration = "Ghasala - Yaghsilu",
            madhi = "غَسَلَ", mudhari = "يَغْسِلُ", masdar = "غَسْلًا",
            fail = "غَاسِلٌ", maful = "مَغْسُوْلٌ", amr = "اِغْسِلْ", nahy = "لَا تَغْسِلْ",
            zaman = "مَغْسِلٌ", makan = "مَغْسِلٌ", alah = "مِغْسَلٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "غَسْلًا (Ghaslan) / غُسْلًا",
            sifatMusyabbahah = "غَسِيْلٌ",
            jamakTaksir = "أَغْسَالٌ",
            shigotMuntahalJumuk = "مَغَاسِلُ (Maghāsil)",
            dictionarySources = "Lisan al-Arab:\nBermakna membersihkan noda baju atau tubuh menggunakan air. Tempat pemandian atau wastafel disebut مَغْسِلٌ atau مَغْسَلٌ ber-Muntahal Jumuk مَغَاسِلُ."
        ),
        ArabicVerb(
            id = "b2_4", root = "ع - ر - f", bab = 2, meaning = "Mengenal/Mengetahui", transliteration = "Arafa - Ya'rifu",
            madhi = "عَرَفَ", mudhari = "يَعْرِفُ", masdar = "مَعْرِفَةً",
            fail = "عَارِفٌ", maful = "مَعْرُوْفٌ", amr = "اِعْرِفْ", nahy = "لَا تَعْرِفْ",
            zaman = "مَعْرِfٌ", makan = "مَعْرِfٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "مَعْرِفَةً (Ma'rifatan) / عِرْفَانًا",
            sifatMusyabbahah = "عَرِيْفٌ",
            jamakTaksir = "مَعَارِفُ (Ma'ārif)",
            shigotMuntahalJumuk = "مَعَارِفُ (Ma'ārif)",
            dictionarySources = "Maqayis al-Lughah:\nAkar 'عرف' mengindikasikan ilmu pengetahuan mendalam yang diperoleh dari silsilah petunjuk. Isim Masdar-nya memiliki jamak taksir مَعَارِفُ."
        ).copy(root = "ع - ر - ف", zaman = "مَعْرِفٌ", makan = "مَعْرِفٌ"),
        ArabicVerb(
            id = "b2_5", root = "ر - ج - ع", bab = 2, meaning = "Kembali/Pulang", transliteration = "Raja'a - Yarji'u",
            madhi = "رَجَعَ", mudhari = "يَرْجِعُ", masdar = "رُجُوْعًا",
            fail = "رَاجِعٌ", maful = "مَرْجُوْعٌ", amr = "اِرْجِعْ", nahy = "لَا تَرْجِعْ",
            zaman = "مَرْجِعٌ", makan = "مَرْجِعٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "رُجُوْعًا (Rujū'an)",
            sifatMusyabbahah = "رَجِيْعٌ",
            jamakTaksir = "مَرَاجِعُ (Marāji')",
            shigotMuntahalJumuk = "مَرَاجِعُ (Marāji')",
            dictionarySources = "Taj al-Arus:\n'رجوع' mengindikasikan pemulihan lintasan ke titik mula asal. Buku referensi rujukan ilmiah dinamakan مَرْجِعٌ, terkumpul dalam jamak taksir مَرَاجِعُ."
        ),

        // --- BAB 3 ---
        ArabicVerb(
            id = "b3_1", root = "ف - ت - ح", bab = 3, meaning = "Membuka", transliteration = "Fataha - Yaftahu",
            madhi = "فَتَحَ", mudhari = "يَفْتَحُ", masdar = "فَتْحًا",
            fail = "فَاتِحٌ", maful = "مَفْتُوْحٌ", amr = "اِفْتَحْ", nahy = "لَا تَفْتَحْ",
            zaman = "مَفْتَحٌ", makan = "مَفْتَحٌ", alah = "مِفْتَحٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "فَتْحًا (Fatḥan)",
            sifatMusyabbahah = "فَتِيْحٌ",
            jamakTaksir = "فُتُوْحٌ",
            shigotMuntahalJumuk = "مَفَاتِيْحُ (Mafātīḥ)",
            dictionarySources = "Lisan al-Arab:\nAkar 'فتح' melambangkan pembebasan atas sumbatan fisik maupun mental spiritual. Kunci pembuka pintu dinamai مِفْتَاحٌ, berkumpul dalam Muntahal Jumuk مَفَاتِيْحُ."
        ),
        ArabicVerb(
            id = "b3_2", root = "ب - ع - ث", bab = 3, meaning = "Mengutus/Mengirim", transliteration = "Ba'atha - Yab'athu",
            madhi = "بَعَثَ", mudhari = "يَبْعَثُ", masdar = "بَعْثًا",
            fail = "بَاعِثٌ", maful = "مَبْعُوْثٌ", amr = "اِبْعَثْ", nahy = "لَا تَبْعَثْ",
            zaman = "مَبْعَثٌ", makan = "مَبْعَثٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "بَعْثًا (Ba'than)",
            sifatMusyabbahah = "بَعِيْثٌ",
            jamakTaksir = "بُعُوْثٌ",
            shigotMuntahalJumuk = "مَبَاعِثُ (Mabā'ith)",
            dictionarySources = "Al-Qamus al-Muhit:\nMenyebarkan pasukan, membangkitkan urusan yang tertidur mati atau tidur lelap. Hari Kebangkitan pasca wafat disebut يَوْمُ البَعْثِ."
        ),
        ArabicVerb(
            id = "b3_3", root = "ج - ع - ل", bab = 3, meaning = "Menjadikan", transliteration = "Ja'ala - Yaj'alu",
            madhi = "جَعَلَ", mudhari = "يَجَعَلُ", masdar = "جَعْلًا",
            fail = "جَاعِلٌ", maful = "مَجْعُوْلٌ", amr = "اِجْعَلْ", nahy = "لَا تَجْعَلْ",
            zaman = "مَجْعَلٌ", makan = "مَجْعَلٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "جَعْلًا (Ja'lan)",
            sifatMusyabbahah = "جَعِيْلٌ",
            jamakTaksir = "جَوَاعِلُ",
            shigotMuntahalJumuk = "مَجَاعِلُ",
            dictionarySources = "Taj al-Arus:\nMengubah, memproses bahan baku mentah menjadi ciptaan spesifik murni lainnya."
        ).copy(mudhari = "يَجْعَلُ"),
        ArabicVerb(
            id = "b3_4", root = "ذ - ه - ب", bab = 3, meaning = "Pergi", transliteration = "Dhahaba - Yadhabu",
            madhi = "ذَهَبَ", mudhari = "يَذْهَبُ", masdar = "ذَهَابًا",
            fail = "ذَاهِبٌ", maful = "مَذْهُوْبٌ", amr = "اِذْهَبْ", nahy = "لَا تَذْهَبْ",
            zaman = "مَذْهَبٌ", makan = "مَذْهَبٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "ذَهَابًا (Dhahāban)",
            sifatMusyabbahah = "ذَهِيْبٌ",
            jamakTaksir = "مَذَاهِبُ",
            shigotMuntahalJumuk = "مَذَاهِبُ (Madhāhib)",
            dictionarySources = "Maqayis al-Lughah:\nMelangkah menyapu ruang kosong menjauh dari asal kediaman semula. Pola fikir sekte keilmuan mazhab fiqih disebut مَذْهَبٌ ber-Jamak Taksir مَذَاهِبُ."
        ),
        ArabicVerb(
            id = "b3_5", root = "ج - م - ع", bab = 3, meaning = "Mengumpulkan", transliteration = "Jama'a - Yajma'u",
            madhi = "جَمَعَ", mudhari = "يَجْمَعُ", masdar = "جَمْعًا",
            fail = "جَامِعٌ", maful = "مَجْمُوْعٌ", amr = "اِجْمَعْ", nahy = "لَا تَجَمَعْ",
            zaman = "مَجْمَعٌ", makan = "مَجْمَعٌ", alah = "مِجْمَعٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "جَمْعًا (Jam'an)",
            sifatMusyabbahah = "جَمِيْعٌ",
            jamakTaksir = "جُمُوعٌ (Jumū')",
            shigotMuntahalJumuk = "مَجَامِعُ (Majāmi')",
            dictionarySources = "Taj al-Arus:\nMenyatukan hal-hal berserakan secara kohesif berkelompok. Hari kiamat dinamakan يَوْمِ جَمْعِ, tempat kumpul bersama مَجْمَعٌ berkoleksi Muntahal Jumuk مَجَامِعُ."
        ).copy(nahy = "لَا تَجْمَعُ"),

        // --- BAB 4 ---
        ArabicVerb(
            id = "b4_1", root = "ع - ل - م", bab = 4, meaning = "Mengetahui", transliteration = "Alima - Ya'lamu",
            madhi = "عَلِمَ", mudhari = "يَعْلَمُ", masdar = "عِلْمًا",
            fail = "عَالِمٌ", maful = "مَعْلُوْمٌ", amr = "اِعْلَمْ", nahy = "لَا تَعْلَمْ",
            zaman = "مَعْلَمٌ", makan = "مَعْلَمٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "عِلْمًا ('Ilman)",
            sifatMusyabbahah = "عَلِيْمٌ",
            jamakTaksir = "عُلُومٌ (Ulūm)",
            shigotMuntahalJumuk = "مَعَالِمُ (Ma'ālim)",
            dictionarySources = "Al-Mu'jam al-Wasit:\nMenguasai esensi hakiki kebenaran realitas kognitif intelektual. Pola tanda arsitektur landmark pengetahu disebut مَعْلَمٌ dengan Muntahal Jumuk مَعَالِمُ."
        ),
        ArabicVerb(
            id = "b4_2", root = "ش - ر - ب", bab = 4, meaning = "Minum", transliteration = "Schariba - Yashrabu",
            madhi = "شَرِبَ", mudhari = "يَشْرَبُ", masdar = "شُرْبًا",
            fail = "شَارِبٌ", maful = "مَشْرُوْبٌ", amr = "اِشْرَبْ", nahy = "لَا تَشْرَبْ",
            zaman = "مَشْرَبٌ", makan = "مَشْرَبٌ", alah = "مِشْرَبٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "شُرْبًا (Shurban)",
            sifatMusyabbahah = "شَرِيْبٌ",
            jamakTaksir = "أَشْرِبَةٌ",
            shigotMuntahalJumuk = "مَشَارِبُ (Mashārib)",
            dictionarySources = "Taj al-Arus:\nMenghisap cairan basah lembut masuk ke tenggorokan hidrasi. Tempat mata air suci hewan dan insan called مَشْرَبٌ, ber-Muntahal Jumuk مَشَارِبُ."
        ),
        ArabicVerb(
            id = "b4_3", root = "ف - ه - م", bab = 4, meaning = "Memahami", transliteration = "Fahima - Yafhamu",
            madhi = "فَهِمَ", mudhari = "يَفْهَمُ", masdar = "فَهْمًا",
            fail = "فَاهِمٌ", maful = "مَفْهُوْمٌ", amr = "اِفْهَمْ", nahy = "لَا تَفْهَمْ",
            zaman = "مَفْهَمٌ", makan = "مَفْهَمٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "فَهْمًا (Fahman)",
            sifatMusyabbahah = "فَهِيْمٌ",
            jamakTaksir = "أَفْهَامٌ",
            shigotMuntahalJumuk = "مَفَاهِمُ (Mafāhim)",
            dictionarySources = "Taj al-Arus:\nMencerna ide abstrak tersembunyi hingga masuk ke substansi intinya."
        ),
        ArabicVerb(
            id = "b4_4", root = "ح - ف - ظ", bab = 4, meaning = "Menghafal/Menjaga", transliteration = "Hafidha - Yahfadhu",
            madhi = "حَفِظَ", mudhari = "يَحْفَظُ", masdar = "حِفْظًا",
            fail = "حَافِظٌ", maful = "مَحْفُوْظٌ", amr = "اِحْفَظْ", nahy = "لَا تَحْفَظْ",
            zaman = "مَحْفَظٌ", makan = "مَحْفَظٌ", alah = "مِحْفَظٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "حِفْظًا (Ḥifẓan)",
            sifatMusyabbahah = "حَفِيْظٌ",
            jamakTaksir = "حَفَظَةٌ / حُفَّاظٌ",
            shigotMuntahalJumuk = "مَحَافِظُ (Maḥāfiẓ)",
            dictionarySources = "Lisan al-Arab:\nMelindungi benda mulia dari kepunahan, kelupaan atau kerusakan eksternal."
        ),
        ArabicVerb(
            id = "b4_5", root = "س - م - ع", bab = 4, meaning = "Mendengar", transliteration = "Sami'a - Yasma'u",
            madhi = "سَمِعَ", mudhari = "يَسْمَعُ", masdar = "سَمْعًا",
            fail = "سَامِعٌ", maful = "مَسْمُوْعٌ", amr = "اِسْمَعْ", nahy = "لَا تَسْمَعْ",
            zaman = "مَسْمَعٌ", makan = "مَسْمَعٌ", alah = "مِسْمَعٌ",
            shorofType = "Salim (Shahih)",
            multipleMasdars = "سَمْعًا (Sam'an)",
            sifatMusyabbahah = "سَمِيْعٌ",
            jamakTaksir = "سُمَّاعٌ",
            shigotMuntahalJumuk = "مَسَامِعُ (Masāmi')",
            dictionarySources = "Taj al-Arus:\nMenangkap getaran suara menggunakan indera telinga secara reseptif biologis."
        ),

        // --- BAB 5 ---
        ArabicVerb(
            id = "b5_1", root = "ح - س - ن", bab = 5, meaning = "Baik/Menjadi Baik", transliteration = "Hasuna - Yahsunu",
            madhi = "حَسُنَ", mudhari = "يَحْسُنُ", masdar = "حُسْنًا",
            fail = "حَسَنٌ", maful = "مَحْسُوْنٌ", amr = "اُحْسُنْ", nahy = "لَا تَحْسُنْ",
            zaman = "مَحْسَنٌ", makan = "مَحْسَنٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "حُسْنًا (Ḥusnan) / حَسَنَةً",
            sifatMusyabbahah = "حَسَنٌ (Ḥasan) / حَسِيْنٌ",
            jamakTaksir = "مَحَاسِنُ",
            shigotMuntahalJumuk = "مَحَاسِنُ (Maḥāsin)",
            dictionarySources = "Lisan al-Arab:\nAkar 'حسن' menunjukkan keelokan rupa kasar lahiriah berserta kemuliaan perilaku akhlak batiniah. Jamak Taksir sastranya مَحَاسِنُ melambangkan segala jenis kebajikan."
        ),
        ArabicVerb(
            id = "b5_2", root = "ك - ب - ر", bab = 5, meaning = "Besar/Menjadi Besar", transliteration = "Kabura - Yakburu",
            madhi = "كَبُرَ", mudhari = "يَكْبُرُ", masdar = "كِبَرًا",
            fail = "كَبِيْرٌ", maful = "مَكْبُوْرٌ", amr = "اُكْبُرْ", nahy = "لَا تَكْبُرْ",
            zaman = "مَكْبَرٌ", makan = "مَكْبَرٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "كِبَرًا (Kibaran) / كَبَارَةً",
            sifatMusyabbahah = "كَبِيْرٌ (Kabīr)",
            jamakTaksir = "كِبَارٌ (Kibār)",
            shigotMuntahalJumuk = "مَكَابِرُ (Makābir)",
            dictionarySources = "Taj al-Arus:\nMengindikasikan pertumbuhan volume fisik berabad-abad atau kemuliaan nama wibawa prestisius."
        ),
        ArabicVerb(
            id = "b5_3", root = "ص - غ - ر", bab = 5, meaning = "Kecil/Menjadi Kecil", transliteration = "Saghura - Yasghuru",
            madhi = "صَغُرَ", mudhari = "يَصْغُرُ", masdar = "صِغَرًا",
            fail = "صَغِيْرٌ", maful = "مَصْغُوْرٌ", amr = "اُصْغُرْ", nahy = "لَا تَصْغُرْ",
            zaman = "مَصْغَرٌ", makan = "مَصْغَرٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "صِغَرًا (Ṣigharan) / صَغَارَةً",
            sifatMusyabbahah = "صَغِيْرٌ (Ṣaghīr)",
            jamakTaksir = "صِغَارٌ (Ṣighār)",
            shigotMuntahalJumuk = "مَصَاغِرُ (Maṣāghir)",
            dictionarySources = "Al-Qamus al-Muhit:\nMenyusut ukuran fisiknya secara drastis, atau merendah hatinya di depan manusia."
        ),

        // --- BAB 6 ---
        ArabicVerb(
            id = "b6_1", root = "ح - s - b", bab = 6, meaning = "Menduga/Menghitung", transliteration = "Hasiba - Yahsibu",
            madhi = "حَسِبَ", mudhari = "يَحْسِبُ", masdar = "حِسْبَانًا",
            fail = "حَاسِبٌ", maful = "مَحْسُوْبٌ", amr = "اِحْسِبْ", nahy = "لَا تَحْسِبْ",
            zaman = "مَحْسِبٌ", makan = "مَحْسِبٌ", alah = null,
            shorofType = "Salim (Shahih)",
            multipleMasdars = "حِسْبَانًا (Ḥisbānan) / حَسْbًا",
            sifatMusyabbahah = "حَسِيْبٌ",
            jamakTaksir = "حُسْبَانٌ",
            shigotMuntahalJumuk = "مَحَاسِبُ (Maḥāsib)",
            dictionarySources = "Taj al-Arus:\nMembangun dugaan matematis kualitatif berdasarkan taksiran angka atau indikasi."
        ).copy(root = "ح - س - ب", multipleMasdars = "حِسْبَانًا (Ḥisbānan) / حَسْبًا"),
        ArabicVerb(
            id = "b6_2", root = "و - ر - ث", bab = 6, meaning = "Mewarisi", transliteration = "Waritha - Yarithu",
            madhi = "وَرِثَ", mudhari = "يَرِثُ", masdar = "وِرَاثَةً",
            fail = "وَارِثٌ", maful = "مَوْرُوْثٌ", amr = "رِثْ", nahy = "لَا تَرِثْ",
            zaman = "مَوْرِثٌ", makan = "مَوْرِثٌ", alah = null,
            shorofType = "Mithal Wawiy (Ghairu Salim)",
            multipleMasdars = "وِرَاثَةً (Wirāthatan) / إِرْثًا",
            sifatMusyabbahah = "وَرِيْثٌ",
            jamakTaksir = "وَرَثَةٌ (Warathah)",
            shigotMuntahalJumuk = "مَوَارِثُ (Mawārith)",
            isimTasghir = "وُرَيْثٌ",
            isimTafdhilMudzakkar = "أَوْرَثُ",
            isimTafdhilMuannats = "وُرْثَى",
            asalKataGhoiruSalim = "Kata 'ورث' bermutasi dengan i'lal jenis Mithal Wawiy. Huruf illah 'و' (Wawu) di awal dihilangkan secara morfologis dalam Fi'il Mudhari' ('يَرِثُ' asalnya 'يَوْرِثُ') karena berada di antara harakat fathah pada huruf ya mudhara'ah dan harakat kasrah pada huruf 'ra' (di antara dua rival vokal).",
            dictionarySources = "Lisan al-Arab:\nMenerima estafet pemilikan harta abadi atau tahta kekuasaan dari pihak pendahulu wafat."
        ),
        ArabicVerb(
            id = "ajwaf_1", root = "ق - و - ل", bab = 1, meaning = "Berkata", transliteration = "Qāla - Yaqūlu",
            madhi = "قَالَ", mudhari = "يَقُوْلُ", masdar = "قَوْلًا",
            fail = "قَائِلٌ", maful = "مَقُوْلٌ", amr = "قُلْ", nahy = "لَا تَقُلْ",
            zaman = "مَقَالٌ", makan = "مَقَالٌ", alah = null,
            shorofType = "Ajwaf Wawiy (Ghairu Salim)",
            multipleMasdars = "قَوْلًا (Qawlan)",
            sifatMusyabbahah = "قَوِيْلٌ",
            jamakTaksir = "أَقْوَالٌ",
            shigotMuntahalJumuk = "مَقَاوِلُ",
            isimTasghir = "قُوَيْلٌ",
            isimTafdhilMudzakkar = "أَقْوَلُ",
            isimTafdhilMuannats = "قُولَى",
            asalKataGhoiruSalim = "Kata 'قَالَ' bermutasi dengan i'lal jenis Ajwaf Wawiy. Huruf alif pada 'قَالَ' asalnya adalah 'و' (asal kata 'قَوَلَ'), fathahnya dipindahkan/diubah mengikuti keselarasan. Pada mudhari 'يَقُوْلُ' asalnya 'يَقْوُلُ', harakat dhommah dari huruf 'و' dipindahkan ke huruf 'ق' (I'lal bin-Naql).",
            dictionarySources = "Taj al-Arus & Maqayis al-Lughah:\nBerkomunikasi menyampaikan perkataan verbal kepada lawan bicara."
        ),
        ArabicVerb(
            id = "naqis_1", root = "ب - ن - ي", bab = 2, meaning = "Membangun", transliteration = "Banā - Yabnī",
            madhi = "بَنَى", mudhari = "يَبْنِيْ", masdar = "بِنَاءً",
            fail = "بَانٍ", maful = "مَبْنِيٌّ", amr = "اِبْنِ", nahy = "لَا تَبْنِ",
            zaman = "مَبْنًى", makan = "مَبْنًى", alah = "مِبْنًى",
            shorofType = "Naqis Ya'iy (Ghairu Salim)",
            multipleMasdars = "بِنَاءً (Binā'an)",
            sifatMusyabbahah = "بَنِيٌّ",
            jamakTaksir = "أَبْنِيَةٌ",
            shigotMuntahalJumuk = "مَبَانٍ",
            isimTasghir = "بُنَيٌّ",
            isimTafdhilMudzakkar = "أَبْنَى",
            isimTafdhilMuannats = "بُنْيَى",
            asalKataGhoiruSalim = "Kata 'بَنَى' mengalami i'lal jenis Naqis Ya'iy. Huruf Ya sukun di akhir adalah ('يْ') contohnya 'يَبْنِيْ', di mana sukun diletakkan (I'lal bit-Tashkin) untuk menolak vokal dhommah yang berat diucapkan pada huruf illah di akhir kata.",
            dictionarySources = "Lisan al-Arab:\nMenyusun batu-bata, pondasi, atau materi fisik/spiritual lainnya sehingga kokoh berdiri."
        ),
        ArabicVerb(
            id = "mudhaaf_1", root = "م - د - د", bab = 1, meaning = "Memanjangkan", transliteration = "Madda - Yamuddu",
            madhi = "مَدَّ", mudhari = "يَمُدُّ", masdar = "مَدًّا",
            fail = "مَادٌّ", maful = "مَمْدُوْدٌ", amr = "مُدَّ", nahy = "لَا تَمُدَّ",
            zaman = "مَمَدٌّ", makan = "مَمَدٌّ", alah = "مِمَدٌّ",
            shorofType = "Mudha'af (Ghairu Salim)",
            multipleMasdars = "مَدًّا (Maddan)",
            sifatMusyabbahah = "مَدِيْدٌ",
            jamakTaksir = "مُدُودٌ",
            shigotMuntahalJumuk = "مَمَادُّ",
            isimTasghir = "مُدَيْدٌ",
            isimTafdhilMudzakkar = "أَمَدُّ",
            isimTafdhilMuannats = "مُدَّى",
            asalKataGhoiruSalim = "Kata 'مَدَّ' mengalami hukum Idgham karena dua huruf Dal (د) sejenis berurutan dibubuhi tanda Tasydid. Ketika bersambung dengan dhomir rafa' mutaharrik (mulai dhomir HUNNA 'مَدَدْنَ' sampai NAHNU 'مَدَدْنَا'), Idgham dilepas (فك الإدغام).",
            dictionarySources = "Al-Qamus al-Muhit:\nMembentangkan tali, memperluas horizon waktu."
        ),
        ArabicVerb(
            id = "lafif_1", root = "ط - و - ي", bab = 2, meaning = "Melipat", transliteration = "Ṭawā - Yaṭwī",
            madhi = "طَوَى", mudhari = "يَطْوِيْ", masdar = "طَيًّا",
            fail = "طَاوٍ", maful = "مَطْوِيٌّ", amr = "اِطْوِ", nahy = "لَا تَطْوِ",
            zaman = "مَطْوًى", makan = "مَطْوًى", alah = "مِطْوًى",
            shorofType = "Lafif Maqrun (Ghairu Salim)",
            multipleMasdars = "طَيًّا (Ṭayyan)",
            sifatMusyabbahah = "طَوِيٌّ",
            jamakTaksir = "أَطْوِيَةٌ",
            shigotMuntahalJumuk = "مَطَاوٍ",
            isimTasghir = "طُوَيٌّ",
            isimTafdhilMudzakkar = "أَطْوَى",
            isimTafdhilMuannats = "طُوَّى",
            asalKataGhoiruSalim = "Kata 'طَوَى' adalah Lafif Maqrun karena memiliki dua huruf illah berdampingan (Wawu dan Ya). Aturan I'lal sama dengan Naqis, di mana huruf Ya akhir mudhari disukunkan 'يَطْوِيْ' (I'lal bit-Tashkin) dan dibuang saat amr 'اِطْوِ'.",
            dictionarySources = "Lisan al-Arab:\nMenggulung lembaran kertas/kain."
        ),
        ArabicVerb(
            id = "lafif_2", root = "و - ق - ي", bab = 2, meaning = "Menjaga", transliteration = "Waqā - Yaqī",
            madhi = "وَقَى", mudhari = "يَقِيْ", masdar = "وِقَايَةً",
            fail = "وَاقٍ", maful = "مَوْقِيٌّ", amr = "قِ", nahy = "لَا تَقِ",
            zaman = "مَوْقًى", makan = "مَوْقًى", alah = "مِيقًى",
            shorofType = "Lafif Mafruq (Ghairu Salim)",
            multipleMasdars = "وِقَايَةً (Wiqāyatan) / وَقْيًا",
            sifatMusyabbahah = "وَقِيٌّ",
            jamakTaksir = "أَوْقِيَةٌ",
            shigotMuntahalJumuk = "مَوَاقٍ",
            isimTasghir = "وُقَيٌّ",
            isimTafdhilMudzakkar = "أَوْقَى",
            isimTafdhilMuannats = "وُقْيَى",
            asalKataGhoiruSalim = "Kata 'وَقَى' adalah Lafif Mafruq karena huruf illah (Wawu dan Ya) dipisahkan oleh huruf shahih (Qaf). Pada mudhari, huruf 'و' dibuang seperti Mithal ('يَقِيْ' asalnya 'يَوْقِيْ'), dan pada amr kedua huruf illah dibuang sehingga tersisa satu huruf saja: 'قِ' dengan harakat kasrah.",
            dictionarySources = "Taj al-Arus:\nMelindungi benda berharga dari bahaya."
        ),
        ArabicVerb(
            id = "mahmuz_1", root = "أ - ك - ل", bab = 1, meaning = "Makan", transliteration = "Akala - Ya'kulu",
            madhi = "أَكَلَ", mudhari = "يَأْكُلُ", masdar = "أَكْلًا",
            fail = "آكِلٌ", maful = "مَأْكُوْلٌ", amr = "كُلْ", nahy = "لَا تَأْكُلْ",
            zaman = "مَأْكَلٌ", makan = "مَأْكَلٌ", alah = "مِأْكَلٌ",
            shorofType = "Mahmuz Fa' (Ghairu Salim)",
            multipleMasdars = "أَكْلًا (Aklan)",
            sifatMusyabbahah = "أَكِيْلٌ",
            jamakTaksir = "أَكَائِلُ",
            shigotMuntahalJumuk = "مَآكِلُ",
            isimTasghir = "أُكَيْلٌ",
            isimTafdhilMudzakkar = "آكَلُ",
            isimTafdhilMuannats = "أُكْلَى",
            asalKataGhoiruSalim = "Kata 'أَكَلَ' adalah Mahmuz Fa' karena fa' fi'ilnya berupa hamzah. Pada fi'il amr 'كُلْ', hamzahnya dibuang secara sima'i (I'lal bil-Hadzfi/tashil khusus) demi memudahkan perbincangan sehari-hari.",
            dictionarySources = "Taj al-Arus:\nMengunyah makanan memasukkannya ke dalam perut untuk asupan energi kehidupan."
        )
    )

    /**
     * Dynamically conjugates healthy (Salim) and Irregular Past Tense (Fi'il Madhi) verbs for 14 pronouns.
     * Incorporates custom I'lal rules for Bina' Naqis dynamically:
     * 1. If weak letter falls after fatha, it is replaced by Alif (e.g. banaya -> bana/banay) UNLESS followed by Dual Alif.
     * 2. After replacing with Alif, if meeting a silent letter (like wawu/ta sukun), Alif is deleted (e.g. banat/banaw).
     * 3. Meeting vowelled nominative pronouns (like ta, tuma, na) or Nun Niswah, the weak letter is sukunized (e.g. banayna, banayta).
     */
    fun conjugateMadhi(madhiString: String): List<String> {
        val trimmed = madhiString.trim().replace("|", "ْ")
        
        when (trimmed) {
            "قَالَ" -> return listOf(
                "قَالَ", "قَالَا", "قَالُوْا", 
                "قَالَتْ", "قَالَتَا", "قُلْنَ", 
                "قُلْتَ", "قُلْتُمَا", "قُلْتُمْ", 
                "قُلْتِ", "قُلْتُمَا", "قُلْتُنَّ", 
                "قُلْتُ", "قُلْنَا"
            )
            "بَنَى" -> return listOf(
                "بَنَى", "بَنَيَا", "بَنَوْا", 
                "بَنَتْ", "بَنَتَا", "بَنَيْنَ", 
                "بَنَيْتَ", "بَنَيْتُمَا", "بَنَيْتُمْ", 
                "بَنَيْتِ", "بَنَيْتُمَا", "بَنَيْتُنَّ", 
                "بَنَيْتُ", "بَنَيْنَا"
            )
            "مَدَّ" -> return listOf(
                "مَدَّ", "مَدَّا", "مَدُّوْا", 
                "مَدَّتْ", "مَدَّتَا", "مَدَدْنَ", 
                "مَدَدْتَ", "مَدَدْتُمَا", "مَدَدْتُمْ", 
                "مَدَدْتِ", "مَدَدْتُمَا", "مَدَدْتُنَّ", 
                "مَدَدْتُ", "مَدَدْنَا"
            )
            "طَوَى" -> return listOf(
                "طَوَى", "طَوَيَا", "طَوَوْا", 
                "طَوَتْ", "طَوَتَا", "طَوَيْنَ", 
                "طَوَيْتَ", "طَوَيْتُمَا", "طَوَيْتُمْ", 
                "طَوَيْتِ", "طَوَيْتُمَا", "طَوَيْتُنَّ", 
                "طَوَيْتُ", "طَوَيْنَا"
            )
            "وَقَى" -> return listOf(
                "وَقَى", "وَقَيَا", "وَقَوْا", 
                "وَقَتْ", "وَقَتَا", "وَقَيْنَ", 
                "وَقَيْتَ", "وَقَيْتُمَا", "وَقَيْتُمْ", 
                "وَقَيْتِ", "وَقَيْتُمَا", "وَقَيْتُنَّ", 
                "وَقَيْتُ", "وَقَيْنَا"
            )
            "أَكَلَ" -> return listOf(
                "أَكَلَ", "أَكَلَا", "أَكَلُوْا", 
                "أَكَلَتْ", "أَكَلَتَا", "أَكَلْنَ", 
                "أَكَلْتَ", "أَكَلْتُمَا", "أَكَلْتُمْ", 
                "أَكَلْتِ", "أَكَلْتُمَا", "أَكَلْتُنَّ", 
                "أَكَلْتُ", "أَكَلْنَا"
            )
            "وَرِثَ" -> return listOf(
                "وَرِثَ", "وَرِثَا", "وَرِثُوْا", 
                "وَرِثَتْ", "وَرِثَتَا", "وَرِثْنَ", 
                "وَرِثْتَ", "وَرِثْتُمَا", "وَرِثْتُمْ", 
                "وَرِثْتِ", "وَرِثْتُمَا", "وَرِثْتُنَّ", 
                "وَرِثْتُ", "وَرِثْنَا"
            )
        }

        val isNaqis = trimmed.endsWith("ى") || trimmed.endsWith("ا") || trimmed.endsWith("ي")
        if (isNaqis) {
            val weakLetter = if (trimmed.endsWith("ا")) "و" else "ي"
            val base = trimmed.substring(0, trimmed.length - 1)
            return listOf(
                trimmed,
                (base + weakLetter + "َا").normalizeArabic(),
                (base + "َوْا").normalizeArabic(),
                (base + "َتْ").normalizeArabic(),
                (base + "َتَا").normalizeArabic(),
                (base + weakLetter + "ْنَ").normalizeArabic(),
                (base + weakLetter + "ْتَ").normalizeArabic(),
                (base + weakLetter + "ْتُمَا").normalizeArabic(),
                (base + weakLetter + "ْتُمْ").normalizeArabic(),
                (base + weakLetter + "ْتِ").normalizeArabic(),
                (base + weakLetter + "ْتُمَا").normalizeArabic(),
                (base + weakLetter + "ْتُنَّ").normalizeArabic(),
                (base + weakLetter + "ْتُ").normalizeArabic(),
                (base + weakLetter + "ْنَا").normalizeArabic()
            )
        }

        val stem = extractMadhiStem(trimmed)
        return listOf(
            trimmed,                                                       // 1. هو (Dia Lk) e.g. نَصَرَ
            stem + "َا",                                                   // 2. هما (Dia Berdua Lk) e.g. نَصَرَا
            stem + "ُوْا",                                                 // 3. هم (Mereka Lk) e.g. نَصَرُوْا
            stem + "َتْ",                                                  // 4. هي (Dia Pr) e.g. نَصَرَتْ
            stem + "َتَا",                                                 // 5. هما f (Dia Berdua Pr) e.g. نَصَرَتَا
            stem + "ْنَ",                                                  // 6. هن (Mereka Pr) e.g. نَصَرْنَ
            stem + "ْتَ",                                                  // 7. أنت (Kamu Lk) e.g. نَصَرْتَ
            stem + "ْتُمَا",                                                // 8. أنتما (Kamu Berdua) e.g. نَصَرْتُمَا
            stem + "ْتُمْ",                                                 // 9. أنتم (Kalian Lk) e.g. نَصَرْتُمْ
            stem + "ْتِ",                                                  // 10. أنتِ (Kamu Pr) e.g. نَصَرْتِ
            stem + "ْتُمَا",                                                // 11. (Same as 8)
            stem + "ْتُنَّ",                                                // 12. أنتن (Kalian Pr) e.g. نَصَرْتُنَّ
            stem + "ْتُ",                                                  // 13. أنا (Saya) e.g. نَصَرْتُ
            stem + "ْنَا"                                                  // 14. نحن (Kami) e.g. نَصَرْنَا
        ).map { it.normalizeArabic() }
    }

    /**
     * Dynamically conjugates healthy (Salim) Present Tense (Fi'il Mudhari) verbs for 14 pronouns.
     */
    fun conjugateMudhari(mudhariString: String): List<String> {
        val trimmed = mudhariString.trim().replace("|", "ْ")
        when (trimmed) {
            "يَقُوْلُ" -> return listOf(
                "يَقُوْلُ", "يَقُوْلَانِ", "يَقُوْلُوْنَ", 
                "تَقُوْلُ", "تَقُوْلَانِ", "يَقُلْنَ", 
                "تَقُوْلُ", "تَقُوْلَانِ", "تَقُوْلُوْنَ", 
                "تَقُوْلِيْنَ", "تَقُوْلَانِ", "تَقُلْنَ", 
                "أَقُوْلُ", "نَقُوْلُ"
            )
            "يَبْنِيْ", "يَبْنِي" -> return listOf(
                "يَبْنِيْ", "يَبْنِيَانِ", "يَبْنُوْنَ", 
                "تَبْنِيْ", "تَبْنِيَانِ", "يَبْنِيْنَ", 
                "تَبْنِيْ", "تَبْنِيَانِ", "تَبْنُوْنَ", 
                "تَبْنِيْنَ", "تَبْنِيَانِ", "تَبْنِيْنَ", 
                "أَبْنِيْ", "نَبْنِيْ"
            )
            "يَمُدُّ" -> return listOf(
                "يَمُدُّ", "يَمُدَّانِ", "يَمُدُّوْنَ", 
                "تَمُدُّ", "تَمُدَّانِ", "يَمْدُدْنَ", 
                "تَمُدُّ", "تَمُدَّانِ", "تَمُدُّوْنَ", 
                "تَمُدِّيْنَ", "تَمُدَّανِ", "يَمْدُدْنَ", 
                "أَمُدُّ", "نَمُدُّ"
            ).map { it.replace("تَمُدَّανِ", "تَمُدَّانِ") }
            "يَطْوِيْ", "يَطْوِي" -> return listOf(
                "يَطْوِيْ", "يَطْوِيَانِ", "يَطْوُوْنَ", 
                "تَطْوِيْ", "تَطْوِيَانِ", "يَطْوِيْنَ", 
                "تَطْوِيْ", "تَطْوِيَانِ", "تَطْوُوْنَ", 
                "تَطْوِيْنَ", "تَطْوِيَانِ", "تَطْوِيْنَ", 
                "أَطْوِيْ", "نَطْوِيْ"
            )
            "يَقِيْ", "يَقِي" -> return listOf(
                "يَقِيْ", "يَقِيَانِ", "يَقُوْنَ", 
                "تَقِيْ", "تَقِيَانِ", "يَقِيْنَ", 
                "تَقِيْ", "تَقِيَانِ", "تَقُوْنَ", 
                "تَقِيْنَ", "تَقِيَانِ", "تَقِيْنَ", 
                "أَقِيْ", "نَقِيْ"
            )
            "يَأْكُلُ" -> return listOf(
                "يَأْكُلُ", "يَأْكُلَانِ", "يَأْكُلُوْنَ", 
                "تَأْكُلُ", "تَأْكُلَانِ", "يَأْكُلْنَ", 
                "تَأْكُلُ", "تَأْكُلَانِ", "تَأْكُلُوْنَ", 
                "تَأْكُلِيْنَ", "تَأْكُلَانِ", "تَأْكُلْنَ", 
                "أَأْكُلُ", "نَأْكُلُ"
            )
            "يَرِثُ" -> return listOf(
                "يَرِثُ", "يَرِثَانِ", "يَرِثُوْنَ", 
                "تَرِثُ", "تَرِثَانِ", "يَرِثْنَ", 
                "تَرِثُ", "تَرِثَانِ", "تَرِثُوْنَ", 
                "تَرِثِيْنَ", "تَرِثَانِ", "تَرِثْنَ", 
                "أَرِثُ", "نَرِثُ"
            )
        }

        val stemOpt = extractMudhariStem(trimmed) ?: return List(14) { "-" }
        
        // Resolve prefix and base (e.g. يَنْصُرُ -> prefix "يَ", stem "نْصُر")
        val prefix = if (trimmed.startsWith("يَ")) "يَ" else if (trimmed.startsWith("ي")) "ي" else "يَ"
        val baseWithoutVowel = stemOpt
        
        return listOf(
            trimmed,                                                                          // 1. هو
            (prefix + baseWithoutVowel + "َانِ").normalizeArabic(),                           // 2. هما
            (prefix + baseWithoutVowel + "ُوْنَ").normalizeArabic(),                           // 3. هم
            ("تَ" + baseWithoutVowel + "ُ").normalizeArabic(),                                 // 4. هي
            ("تَ" + baseWithoutVowel + "َانِ").normalizeArabic(),                              // 5. هما f
            (prefix + baseWithoutVowel + "ْنَ").normalizeArabic(),                             // 6. هن
            ("تَ" + baseWithoutVowel + "ُ").normalizeArabic(),                                 // 7. أنت
            ("تَ" + baseWithoutVowel + "َانِ").normalizeArabic(),                              // 8. أنتما
            ("تَ" + baseWithoutVowel + "ُوْنَ").normalizeArabic(),                             // 9. أنتم
            ("تَ" + baseWithoutVowel + "ِيْنَ").normalizeArabic(),                             // 10. أنتِ
            ("تَ" + baseWithoutVowel + "َانِ").normalizeArabic(),                              // 11. (Same as 8)
            ("تَ" + baseWithoutVowel + "ْنَ").normalizeArabic(),                               // 12. أنتن
            ("أَ" + baseWithoutVowel + "ُ").normalizeArabic(),                                 // 13. أنا
            ("نَ" + baseWithoutVowel + "ُ").normalizeArabic()                                  // 14. نحن
        )
    }

    /**
     * Dynamically conjugates healthy (Salim) Imperative (Fi'il Amr) verbs for 6 pronouns (second personas only).
     */
    fun conjugateAmr(amrString: String): List<String> {
        val trimmed = amrString.trim().replace("|", "ْ")
        when (trimmed) {
            "قُلْ" -> return listOf(
                "قُلْ", "قُوْلَا", "قُوْلُوْا", 
                "قُوْلِيْ", "قُوْلَا", "قُلْنَ"
            )
            "اِبْنِ" -> return listOf(
                "اِبْنِ", "اِبْنِيَا", "اِبْنُوْا", 
                "اِبْنِيْ", "اِبْنِيَا", "اِبْنِيْنَ"
            )
            "مُدَّ" -> return listOf(
                "مُدَّ", "مُدَّا", "مُدُّوْا", 
                "مُدِّيْ", "مُدَّا", "اُمْدُدْنَ"
            )
            "اِطْوِ" -> return listOf(
                "اِطْوِ", "اِطْوِيَا", "اِطْوُوْا", 
                "اِطْوِيْ", "اِطْوِيَا", "اِطْوِيْنَ"
            )
            "قِ" -> return listOf(
                "قِ", "قِيَا", "قُوْا", 
                "قِيْ", "قِيَا", "قِيْنَ"
            )
            "كُلْ" -> return listOf(
                "كُلْ", "كُلَا", "كُلُوْا", 
                "كُلِيْ", "كُلَا", "كُلْنَ"
            )
            "رِثْ" -> return listOf(
                "رِثْ", "رِثَا", "رِثُوْا", 
                "رِثِيْ", "رِثَا", "رِثْنَ"
            )
        }

        // amr: e.g. "اُنْصُرْ"
        val stem = if (trimmed.endsWith("ْ")) {
            trimmed.substring(0, trimmed.length - 1)
        } else {
            trimmed
        }
        return listOf(
            trimmed,                                               // 1. أنت e.g. اُنْصُرْ
            (stem + "َا").normalizeArabic(),                       // 2. أنتما e.g. اُنْصُرَا
            (stem + "ُوْا").normalizeArabic(),                     // 3. أنtum e.g. اُنْصُرُوْا
            (stem + "ِيْ").normalizeArabic(),                      // 4. أنتِ e.g. اُنْصُرِيْ
            (stem + "َا").normalizeArabic(),                       // 5. أنتما f (same as 2)
            (stem + "ْنَ").normalizeArabic()                       // 6. أنtin e.g. اُنْصُرْنَ
        )
    }

    /**
     * Dynamically conjugates healthy (Salim) Prohibitive (Fi'il Nahi) verbs for 6 pronouns (second personas only).
     */
    fun conjugateNahi(nahiString: String): List<String> {
        val trimmed = nahiString.trim().replace("|", "ْ")
        
        // Exact lookups based on verb roots
        when {
            trimmed.endsWith("تَقُلْ") || trimmed.contains("تَقُلْ") -> return listOf(
                "لَا تَقُلْ", "لَا تَقُوْلَا", "لَا تَقُوْلُوْا", 
                "لَا تَقُوْلِيْ", "لَا تَقُوْلَا", "لَا تَقُلْنَ"
            )
            trimmed.endsWith("تَبْنِ") || trimmed.contains("تَبْنِ") -> return listOf(
                "لَا تَبْنِ", "لَا تَبْنِيَا", "لَا تَبْنُوْا", 
                "لَا تَبْنِيْ", "لَا تَبْنِيَا", "لَا تَبْنِيْنَ"
            )
            trimmed.endsWith("تَمُدَّ") || trimmed.contains("تَمُدَّ") -> return listOf(
                "لَا تَمُدَّ", "لَا تَمُدَّا", "لَا تَمُدُّوْا", 
                "لَا تَمُدِّيْ", "لَا تَمُدَّا", "لَا تَمْدُدْنَ"
            )
            trimmed.endsWith("تَطْوِ") || trimmed.contains("تَطْوِ") -> return listOf(
                "لَا تَطْوِ", "لَا تَطْوِيَا", "لَا تَطْوُوْا", 
                "لَا تَطْوِيْ", "لَا تَطْوِيَا", "لَا تَطْوِيْنَ"
            )
            trimmed.endsWith("تَقِ") || trimmed.contains("تَقِ") -> return listOf(
                "لَا تَقِ", "لَا تَقِيَا", "لَا تَقُوْا", 
                "لَا تَقِيْ", "لَا تَقِيَا", "لَا تَقِيْنَ"
            )
            trimmed.endsWith("تَاْكُلْ") || trimmed.contains("تَاْكُلْ") || trimmed.contains("تَأْكُلْ") -> return listOf(
                "لَا تَأْكُلْ", "لَا تَأْكُلَا", "لَا تَأْكُلُوْا", 
                "لَا تَأْكُلِيْ", "لَا تَأْكُلَا", "لَا تَأْكُلْنَ"
            )
            trimmed.endsWith("تَرِثْ") || trimmed.contains("تَرِثْ") -> return listOf(
                "لَا تَرِثْ", "لَا تَرِثَا", "لَا تَرِثُوْا", 
                "لَا تَرِثِيْ", "لَا تَرِثَا", "لَا تَرِثْنَ"
            )
        }

        // Default dynamic fallback
        // input nahiString of salim is typically formatted as "لَا تَنْصُرْ".
        val clean = trimmed.replace("لَا", "").trim()
        val stem = if (clean.endsWith("ْ")) {
            clean.substring(0, clean.length - 1)
        } else {
            clean
        }
        return listOf(
            "لَا $clean",
            ("لَا " + stem + "َا").normalizeArabic(),
            ("لَا " + stem + "ُوْا").normalizeArabic(),
            ("لَا " + stem + "ِيْ").normalizeArabic(),
            ("لَا " + stem + "َا").normalizeArabic(),
            ("لَا " + stem + "ْنَ").normalizeArabic()
        )
    }

    /**
     * Dynamically conjugates healthy active/passive noun forms (e.g. Isim Fa'il, Isim Maf'ul)
     * across 6 states (Mufrad Mudzakkar, Tatsniyah Mudzakkar, Jamak Mudzakkar, Mufrad Muannats, Tatsniyah Muannats, Jamak Muannats).
     */
    fun conjugateNoun(nounString: String): List<String> {
        val trimmed = nounString.trim()
        
        when (trimmed) {
            // Isim Fa'il Lookup Table
            "بَانٍ" -> return listOf("بَانٍ", "بَانِيَانِ", "بَانُوْنَ", "بَانِيَةٌ", "بَانِيَتَانِ", "بَانِيَاتٌ")
            "طَاوٍ" -> return listOf("طَاوٍ", "طَاوِيَانِ", "طَاوُوْنَ", "طَاوِيَةٌ", "طَاوِيَتَانِ", "طَاوِيَاتٌ")
            "وَاقٍ" -> return listOf("وَاقٍ", "وَاقِيَانِ", "وَاقُوْنَ", "وَاقِيَةٌ", "وَاقِيَتَانِ", "وَاقِيَاتٌ")
            "قَائِلٌ" -> return listOf("قَائِلٌ", "قَائِلَانِ", "قَائِلُوْنَ", "قَائِلَةٌ", "قَائِلَتَانِ", "قَائِلَاتٌ")
            "مَادٌّ" -> return listOf("مَادٌّ", "مَادَّانِ", "مَادُّوْنَ", "مَادَّةٌ", "مَادَّتَانِ", "مَادَّاتٌ")
            "آكِلٌ" -> return listOf("آكِلٌ", "آكِلَانِ", "آكِلُوْنَ", "آكِلَةٌ", "آكِلَتَانِ", "آكِلَاتٌ")
            "وَارِثٌ" -> return listOf("وَارِثٌ", "وَارِثَانِ", "وَارِثُوْنَ", "وَارِثَةٌ", "وَارِثَتَانِ", "وَارِثَاتٌ")
            
            // Isim Maf'ul Lookup Table
            "مَقُوْلٌ" -> return listOf("مَقُوْلٌ", "مَقُوْلَانِ", "مَقُوْلُوْنَ", "مَقُوْلَةٌ", "مَقُوْلَتَانِ", "مَقُوْلَاتٌ")
            "مَبْنِيٌّ" -> return listOf("مَبْنِيٌّ", "مَبْنِيَّانِ", "مَبْنِيُّوْنَ", "مَبْنِيَّةٌ", "مَبْنِيَّتَانِ", "مَبْنِيَّاتٌ")
            "مَطْوِيٌّ" -> return listOf("مَطْوِيٌّ", "مَطْوِيَّانِ", "مَطْوِيُّوْنَ", "مَطْوِيَّةٌ", "مَطْوِيَّتَانِ", "مَطْوِيَّاتٌ")
            "مَوْقِيٌّ" -> return listOf("مَوْقِيٌّ", "مَوْقِيَّانِ", "مَوْقِيُّوْنَ", "مَوْقِيَّةٌ", "مَوْقِيَّتَانِ", "مَوْقِيَّاتٌ")
            "مَمْدُوْدٌ" -> return listOf("مَمْدُوْدٌ", "مَمْدُوْدَانِ", "مَمْدُوْدُوْنَ", "مَمْدُوْدَةٌ", "مَمْدُوْدَتَانِ", "مَمْدُوْدَاتٌ")
            "مَأْكُوْلٌ" -> return listOf("مَأْكُوْلٌ", "مَأْكُوْلَانِ", "مَأْكُوْلُوْنَ", "مَأْكُوْلَةٌ", "مَأْكُوْلَتَانِ", "مَأْكُوْلَاتٌ")
            "مَوْرُوْثٌ" -> return listOf("مَوْرُوْثٌ", "مَوْرُوْثَانِ", "مَوْرُوْثُوْنَ", "مَوْرُوْثَةٌ", "مَوْرُوْثَتَانِ", "مَوْرُوْثَاتٌ")
            
            // Sifat Musyabbahah Lookup Table
            "قَوِيْلٌ" -> return listOf("قَوِيْلٌ", "قَوِيْلَانِ", "قَوِيْلُوْنَ", "قَوِيْلَةٌ", "قَوِيْلَتَانِ", "قَوِيْلَاتٌ")
            "بَنِيٌّ" -> return listOf("بَنِيٌّ", "بَنِيَّانِ", "بَنِيُّوْنَ", "بَنِيَّةٌ", "بَنِيَّتَانِ", "بَنِيَّاتٌ")
            "طَوِيٌ" -> return listOf("طَوِيٌّ", "طَوِيَّانِ", "طَوِيُّوْنَ", "طَوِيَّةٌ", "طَوِيَّتَانِ", "طَوِيَّاتٌ")
            "طَوِيٌّ" -> return listOf("طَوِيٌّ", "طَوِيَّanِ", "طَوِيُّوْنَ", "طَوِيَّةٌ", "طَوِيَّتَانِ", "طَوِيَّاتٌ").map { it.replace("طَوِيَّanِ", "طَوِيَّanِ") }
            "وَقِيٌ" -> return listOf("وَقِيٌّ", "وَقِيَّانِ", "وَقِيُّوْنَ", "وَقِيَّةٌ", "وَقِيَّتَانِ", "وَقِيَّاتٌ")
            "وَقِيٌّ" -> return listOf("وَقِيٌّ", "وَقِيَّانِ", "وَقِيُّوْنَ", "وَقِيَّةٌ", "وَقِيَّتَانِ", "وَقِيَّاتٌ")
            "مَدِيْدٌ" -> return listOf("مَدِيْدٌ", "مَدِيْدَانِ", "مَدِيْدُوْنَ", "مَدِيْدَةٌ", "مَدِيْدَتَانِ", "مَدِيْدَاتٌ")
            "أَكِيْلٌ" -> return listOf("أَكِيْلٌ", "أَكِيْلَانِ", "أَكِيْلُوْنَ", "أَكِيْلَةٌ", "أَكِيْلَتَانِ", "أَكِيْلَاتٌ")
            "وَرِيْثٌ" -> return listOf("وَرِيْثٌ", "وَرِيْثَانِ", "وَرِيْثُوْنَ", "وَرِيْثَةٌ", "وَرِيْثَتَانِ", "وَرِيْثَاتٌ")

            // Isim Tasghir Lookup Table
            "قُوَيْلٌ" -> return listOf("قُوَيْلٌ", "قُوَيْلَانِ", "قُوَيْلُوْنَ", "قُوَيْلَةٌ", "قُوَيْلَتَانِ", "قُوَيْلَاتٌ")
            "بُنَيٌ" -> return listOf("بُنَيٌّ", "بُنَيَّانِ", "بُنَيُّوْنَ", "بُنَيَّةٌ", "بُنَيَّتَانِ", "بُنَيَّاتٌ")
            "بُنَيٌّ" -> return listOf("بُنَيٌّ", "بُنَيَّانِ", "بُنَيُّوْنَ", "بُنَيَّةٌ", "بُنَيَّتَانِ", "بُنَيَّاتٌ")
            "طُوَيٌ" -> return listOf("طُوَيٌّ", "طُوَيَّانِ", "طُوَيُّوْنَ", "طُوَيَّةٌ", "طُوَيَّتَانِ", "طُوَيَّاتٌ")
            "طُوَيٌّ" -> return listOf("طُوَيٌّ", "طُوَيَّanِ", "طُوَيُّوْنَ", "طُوَيَّةٌ", "طُوَيَّتَانِ", "طُوَيَّاتٌ").map { it.replace("طُوَيَّanِ", "طُوَيَّanِ") }
            "وُقَيٌّ", "وُقَيٌ" -> return listOf("وُقَيٌّ", "وُقَيَّانِ", "وُقَيُّوْنَ", "وُقَيَّةٌ", "وُقَيَّتَانِ", "وُقَيَّاتٌ")
            "مُدَيْدٌ" -> return listOf("مُدَيْدٌ", "مُدَيْدَانِ", "مُدَيْدُوْنَ", "مُدَيْدَةٌ", "مُدَيْدَتَانِ", "مُدَيْدَاتٌ")
            "أُكَيْلٌ" -> return listOf("أُكَيْلٌ", "أُكَيْلَانِ", "أُكَيْلُوْنَ", "أُكَيْلَةٌ", "أُكَيْلَتَانِ", "أُكَيْلَاتٌ")
            "وُرَيْثٌ" -> return listOf("وُرَيْثٌ", "وُرَيْثَانِ", "وُرَيْثُوْنَ", "وُرَيْثَةٌ", "وُرَيْثَتَانِ", "وُرَيْثَاتٌ")
        }

        val base = nounString
            .replace("ٌ", "")
            .replace("َ", "")
            .replace("ُ", "")
            .replace("ِ", "")
            .replace("ً", "")
            .replace("ٍ", "")
            .replace("ّ", "")
            .trim()

        val endsWithTaMarbutah = base.endsWith("ة")
        if (endsWithTaMarbutah) {
            val stem = base.substring(0, base.length - 1)
            return listOf(
                stem + "َةٌ",                         // 1. Mufrad
                stem + "َتَانِ",                     // 2. Tatsniyah
                stem + "َاتٌ",                        // 3. Jamak Muannats
                stem + "َةٌ",
                stem + "َتَانِ",
                stem + "َاتٌ"
            ).map { it.normalizeArabic() }
        }

        return listOf(
            base + "ٌ",                             // 1. Mufrad Mudzakkar
            base + "َانِ",                         // 2. Tatsniyah Mudzakkar
            base + "ُوْنَ",                         // 3. Jamak Mudzakkar
            base + "َةٌ",                           // 4. Mufrad Muannats
            base + "َتَانِ",                       // 5. Tatsniyah Muannats
            base + "َاتٌ"                           // 6. Jamak Muannats
        ).map { it.normalizeArabic() }
    }

    /**
     * Conjugates Isim Fail with custom Jamak Taksir broken plural forms:
     * - فُعَّل (Fu''al)
     * - فُعَّال (Fu''al)
     * - فَعَلَة (Fa'alah)
     * Accommodates specific I'lal rules for Irregular (Ghairu Salim) verbs natively.
     */
    fun conjugateFailWithPlurals(verb: ArabicVerb): List<String> {
        val baseWord = verb.fail
        if (verb.bab == 5 || baseWord.isBlank() || baseWord == "-") {
            return List(9) { "-" }
        }

        // 1. Get standard conjugated forms
        val std = conjugateNoun(baseWord)

        // 2. Derive the 3 broken plurals
        val rootLetters = verb.root.replace(" ", "").split("-").map { it.trim() }.filter { it.isNotEmpty() }
        val brokenPlurals = if (rootLetters.size == 3) {
            val f = rootLetters[0]
            val a = rootLetters[1]
            val l = rootLetters[2]

            when (verb.id) {
                "naqis_1" -> {
                    // بَنَى: بُنَّى, بُنَّاءٌ, بَنَاةٌ
                    listOf("بُنَّى", "بُنَّاءٌ", "بَنَاةٌ")
                }
                "lafif_1" -> {
                    // طَوَى: طُوَّى, طُوَّاءٌ, طَوَاةٌ
                    listOf("طُوَّى", "طُوَّاءٌ", "طَوَاةٌ")
                }
                "lafif_2" -> {
                    // وَقَى: وُقَّى, وُقَّاءٌ, وُقَاةٌ
                    listOf("وُقَّى", "وُقَّاءٌ", "وُقَاةٌ")
                }
                "ajwaf_1" -> {
                    // قَالَ: قُوَّلٌ, قُوَّالٌ, قَالَةٌ
                    listOf("قُوَّلٌ", "قُوَّالٌ", "قَالَةٌ")
                }
                "mudhaaf_1" -> {
                    // مَدَّ: مُدَّدٌ, مُدَّادٌ, مَدَدَةٌ
                    listOf("مُدَّدٌ", "مُدَّادٌ", "مَدَدَةٌ")
                }
                else -> {
                    // Salim/Standard
                    val fu_al = "${f}ُ${a}َّ${l}ٌ"  // فُعَّلٌ
                    val fu_aal = "${f}ُ${a}َّا${l}ٌ" // فُعَّالٌ
                    val fa_alah = "${f}َ${a}َ${l}َةٌ" // فَعَلَةٌ
                    listOf(fu_al, fu_aal, fa_alah)
                }
            }
        } else {
            listOf("-", "-", "-")
        }

        // 3. Assemble: Interleave so plural forms are stacked with masculine forms nicely
        return listOf(
            std[0], // Mufrad Mudzakkar
            std[1], // Tatsniyah Mudzakkar
            std[2], // Jamak Mudzakkar
            brokenPlurals[0].normalizeArabic(),  // Jamak Taksir (فُعَّل)
            brokenPlurals[1].normalizeArabic(),  // Jamak Taksir (فُعَّال)
            brokenPlurals[2].normalizeArabic(),  // Jamak Taksir (فَعَلَة)
            std[3], // Mufrad Muannats
            std[4], // Tatsniyah Muannats
            std[5]  // Jamak Muannats
        )
    }

    /**
     * Dynamically conjugates Zaman, Makan, and Alah nouns into 3 logical states
     * (Singular/Mufrad, Dual/Tatsniyah, and Broken Plural/Jamak Taksir under Muntahal Jumuk formulas).
     */
    fun conjugateZamanMakanAlah(nounString: String, root: String, isAlah: Boolean): List<String> {
        val base = nounString
            .replace("ٌ", "")
            .replace("َ", "")
            .replace("ُ", "")
            .replace("ِ", "")
            .replace("ْ", "")
            .replace("ّ", "")
            .trim()

        val dual = base + "َانِ"

        val rootLetters = root.replace(" ", "").split("-").map { it.trim() }.filter { it.isNotEmpty() }
        val jamak = if (rootLetters.size == 3) {
            val f = rootLetters[0]
            val a = rootLetters[1]
            val l = rootLetters[2]

            if (isAlah && nounString.contains("ا")) { // e.g., مِفْتَاح
                "مَ" + f + "َ" + "ا" + a + "ِ" + "يْ" + l + "ُ"
            } else {
                "مَ" + f + "َ" + "ا" + a + "ِ" + l + "ُ"
            }
        } else {
            base + "َاتٌ"
        }

        return listOf(
            nounString,
            dual.normalizeArabic(),
            jamak.normalizeArabic()
        )
    }

    /**
     * Conjugates Isim Tafdhil Mudzakkar dynamically or looking up specialized rules.
     */
    fun conjugateTafdhilMudzakkar(tafdhilString: String): List<String> {
        val trimmed = tafdhilString.trim()
        val special = when (trimmed) {
            "أَقْوَمُ", "أَقْوَم", "أَقْوَلُ" -> listOf("أَقْوَمُ", "أَقْوَمَانِ", "أَقْوَمُوْنَ")
            "أَبْنَى" -> listOf("أَبْنَى", "أَبْنَيَانِ", "أَبْنَوْنَ")
            "أَمَدُّ" -> listOf("أَمَدُّ", "أَمَدَّانِ", "أَمَدُّوْنَ")
            "أَطْوَى" -> listOf("أَطْوَى", "أَطْوَيَانِ", "أَطْوَوْنَ")
            "أَوْقَى" -> listOf("أَوْقَى", "أَوْقَيَانِ", "أَوْقَوْنَ")
            "أَوْرَثُ" -> listOf("أَوْرَثُ", "أَوْرَثَانِ", "أَوْرَثُوْنَ")
            "آكَلُ" -> listOf("آكَلُ", "آكَلَانِ", "آكَلُوْنَ")
            else -> null
        }
        if (special != null) return special.map { it.normalizeArabic() }

        val base = trimmed
            .replace("ٌ", "")
            .replace("َ", "")
            .replace("ُ", "")
            .replace("ِ", "")
            .replace("ْ", "")
            .replace("ّ", "")
            .trim()

        return listOf(
            base + "ُ",                     // 1. Mufrad Mudzakkar
            base + "َانِ",                 // 2. Tatsniyah Mudzakkar
            base + "ُوْنَ"                 // 3. Jamak Mudzakkar
        ).map { it.normalizeArabic() }
    }

    /**
     * Conjugates Isim Tafdhil Muannats dynamically or looking up specialized rules.
     */
    fun conjugateTafdhilMuannats(tafdhilString: String): List<String> {
        val trimmed = tafdhilString.trim()
        val special = when (trimmed) {
            "قُوْلَى", "قُوَّى" -> listOf("قُوَّى", "قُوَّيَانِ", "قُوَّيَاتٌ")
            "بُنْيَى" -> listOf("بُنْيَى", "بُنْيَيَانِ", "بُنْيَيَاتٌ")
            "مُدَّى" -> listOf("مُدَّى", "مُدَّيَانِ", "مُدَّيَاتٌ")
            "طُوَّى" -> listOf("طُوَّى", "طُوَّيَانِ", "طُوَّيَاتٌ")
            "وُقْيَى" -> listOf("وُقْيَى", "وُقْيَيَانِ", "وُقْيَيَاتٌ")
            "وُرْثَى" -> listOf("وُرْثَى", "وُرْثَيَانِ", "وُرْثَيَاتٌ")
            "أُكْلَى" -> listOf("أُكْلَى", "أُكْلَيَانِ", "أُكْلَيَاتٌ")
            else -> null
        }
        if (special != null) return special.map { it.normalizeArabic() }

        val stripped = trimmed
            .replace("ّ", "")
            .replace("ٌ", "")
            .replace("ً", "")
            .replace("ٍ", "")
        
        val base = if (stripped.endsWith("ى") || stripped.endsWith("ي")) {
            stripped.substring(0, stripped.length - 1)
        } else {
            stripped
        }

        return listOf(
            base + "َى",                      // 1. Mufrad Muannats
            base + "َيَانِ",                  // 2. Tatsniyah Muannats
            base + "َيَاتٌ"                   // 3. Jamak Muannats
        ).map { it.normalizeArabic() }
    }

    private fun extractMadhiStem(madhi: String): String {
        return if (madhi.endsWith("َ")) {
            madhi.substring(0, madhi.length - 1)
        } else {
            madhi
        }
    }

    private fun extractMudhariStem(mudhari: String): String? {
        var cleaned = mudhari
        if (cleaned.startsWith("يَ")) {
            cleaned = cleaned.substring(2)
        } else if (cleaned.startsWith("ي")) {
            cleaned = cleaned.substring(1)
        }
        
        if (cleaned.endsWith("ُ")) {
            cleaned = cleaned.substring(0, cleaned.length - 1)
        }
        return cleaned
    }

    private fun Char.isArabicVowel(): Boolean {
        return this == 'َ' || this == 'ُ' || this == 'ِ' || this == 'ْ' || this == 'ّ'
    }

    private fun String.normalizeArabic(): String {
        return this.replace("ْْ", "ْ")
            .replace("ََ", "َ")
            .replace("ُُ", "ُ")
    }
}
