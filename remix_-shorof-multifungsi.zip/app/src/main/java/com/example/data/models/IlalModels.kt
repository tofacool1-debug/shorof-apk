package com.example.data.models

data class IlalRule(
    val number: Int,
    val name: String,
    val arabicFormula: String,
    val indonesianExplanation: String,
    val exampleBefore: String,
    val exampleAfter: String,
    val category: String
) {
    fun isAppliesTo(verbType: String): Boolean {
        val lowerType = verbType.lowercase()
        return when (number) {
            1 -> lowerType.contains("ajwaf") || lowerType.contains("naqis") || lowerType.contains("lafif")
            2 -> lowerType.contains("naqis") || lowerType.contains("lafif")
            3 -> lowerType.contains("mithal") || lowerType.contains("ajwaf")
            4 -> lowerType.contains("ajwaf") || lowerType.contains("naqis")
            5 -> lowerType.contains("ajwaf")
            6 -> lowerType.contains("ajwaf")
            7 -> lowerType.contains("naqis") || lowerType.contains("lafif")
            8 -> lowerType.contains("mithal")
            9 -> lowerType.contains("ajwaf") || lowerType.contains("naqis")
            10 -> lowerType.contains("mudha") || lowerType.contains("muda") || lowerType.contains("tasydid")
            11 -> lowerType.contains("naqis")
            12 -> lowerType.contains("naqis") || lowerType.contains("lafif")
            13 -> lowerType.contains("naqis") || lowerType.contains("lafif")
            14 -> lowerType.contains("lafif")
            15 -> lowerType.contains("ajwaf")
            16 -> lowerType.contains("ajwaf")
            17 -> lowerType.contains("mahmuz")
            18 -> lowerType.contains("mithal") || lowerType.contains("lafif")
            19 -> lowerType.contains("mahmuz")
            else -> false
        }
    }
}

object IlalData {
    val RULES = listOf(
        IlalRule(
            number = 1,
            name = "Kaidah Ke-1: Penukaran Wau/Ya Menjadi Alif",
            arabicFormula = "إِذَا تَحَرَّكَتِ الْوَاوُ أَوِ الْيَاءُ بَعْدَ فَتْحَةٍ مُتَّصِلَةٍ فِي كَلِمَةٍ وَاحِدَةٍ قُلِبَتَا أَلِفًا",
            indonesianExplanation = "Apabila ada Wau (و) atau Ya (ي) berharakat jatuh setelah harakat fathah dalam satu kata (sambung), maka Wau/Ya tersebut diganti menjadi Alif. Ini adalah fondasi pembentukan fi'il mu'tal ajwaf dan naqis.",
            exampleBefore = "قَوَلَ (Qawala), بَنَيَ (Banaya)",
            exampleAfter = "قَالَ (Qāla), بَنَى (Banā)",
            category = "Ajwaf & Naqis & Lafif"
        ),
        IlalRule(
            number = 2,
            name = "Kaidah Ke-2: Penukaran Wau Menjadi Ya di Akhir setelah Kasrah",
            arabicFormula = "إِذَا وَقَعَتِ الْوَاوُ فِي الْمَقْطَعِ الْأَخِيرِ بَعْدَ كَسْرَةٍ قُلِبَتْ يَاءً",
            indonesianExplanation = "Apabila ada huruf Wau (و) berada di akhir kata dan jatuh setelah harakat kasrah, maka Wau tersebut wajib diganti menjadi Ya (ي) untuk menyelaraskan pengucapan.",
            exampleBefore = "رَضِوَ (Radhiwa)",
            exampleAfter = "رَضِيَ (Radhiya)",
            category = "Naqis & Lafif"
        ),
        IlalRule(
            number = 3,
            name = "Kaidah Ke-3: Penukaran Ya Menjadi Wau setelah Dhommah",
            arabicFormula = "إِذَا وَقَعَتِ الْيَاءُ سَاكِنَةً بَعْدَ ضَمَّةٍ فِي غَيْرِ جَمْعٍ قُلِبَتْ وَاوًا",
            indonesianExplanation = "Apabila ada huruf Ya (ي) sukun (mati) jatuh setelah harakat dhommah pada selain isim jamak, maka Ya tersebut ditukar menjadi Wau (و) demi keselarasan vokal dhommah.",
            exampleBefore = "يُيْسِرُ (Yuy-siru)",
            exampleAfter = "يُوْسِرُ (Yūsiru)",
            category = "Mithal & Ajwaf"
        ),
        IlalRule(
            number = 4,
            name = "Kaidah Ke-4: I'lal bin-Naql (Pemindahan Harakat ke Huruf Shahih Sukun)",
            arabicFormula = "إِذَا كَانَتِ الْوَاوُ أَوِ الْيَاءُ مُتَهَرِّكَةً وَكَانَ مَا قَبْلَهَا سَاكِنًا صَحِيحًا نُقِلَتْ حَرَكَتُهَا إِلَيْهِ",
            indonesianExplanation = "Apabila ada huruf illah (Wau atau Ya) berharakat, sedangkan huruf sebelumnya berupa huruf shahih yang sukun, maka harakat huruf illah dipindahkan ke huruf shahih sebelumnya. Apabila harakat dhommah ditukar ke Wau sukun, atau kasrah ke Ya sukun.",
            exampleBefore = "يَقْوُلُ (Yaqwulu), يَبْنِيُ (Yabniyu)",
            exampleAfter = "يَقُوْلُ (Yaqūlu), يَبْنِيْ (Yabnī)",
            category = "Ajwaf & Naqis"
        ),
        IlalRule(
            number = 5,
            name = "Kaidah Ke-5: Penukaran Wau/Ya Menjadi Hamzah Pada Isim Fail",
            arabicFormula = "إِذَا وَقَعَتِ الْوَاوُ أَوِ الْيَاءُ بَعْدَ أَلِفِ فَاعِلٍ قُلِبَتَا هَمْزَةً",
            indonesianExplanation = "Apabila ada Wau (و) atau Ya (ي) jatuh setelah Alif tambahan (zaidah) pada wazan Isim Fa'il (فَاعِلٌ), maka huruf illah tersebut diganti menjadi Hamzah (ء).",
            exampleBefore = "قَاوِلٌ (Qawilun), بَايِعٌ (Bayi'un)",
            exampleAfter = "قَائِلٌ (Qā'ilun), بَائِعٌ (Bā'i'un)",
            category = "Ajwaf"
        ),
        IlalRule(
            number = 6,
            name = "Kaidah Ke-6: Pertemuan Wau dan Ya dalam Satu Kata",
            arabicFormula = "إِذَا اجْتَمَعَتِ الْوَاوُ وَالْيَاءُ فِي كَلِمَةٍ وَاحِدَةٍ وَسَبَقَتْ إِحْدَاهُمَا بِالسُّكُونِ قُلِبَتِ الْوَاوُ يَاءً وَأُدْغِمَتْ",
            indonesianExplanation = "Apabila dalam satu kata berkumpul huruf Wau (و) dan Ya (ي) secara berdampingan, dan salah satu dari keduanya berharakat sukun di awal, maka Wau ditukar menjadi Ya, lalu diidghamkan (diberi tasydid).",
            exampleBefore = "سَيْوِدٌ (Saywidun), مَيْوِتٌ (Maywitun)",
            exampleAfter = "سَيِّدٌ (Sayyidun), مَيِّتٌ (Mayyitun)",
            category = "Ajwaf & Mudha'af"
        ),
        IlalRule(
            number = 7,
            name = "Kaidah Ke-7: Penukaran Wau/Ya di Akhir Menjadi Hamzah setelah Alif Zaidah",
            arabicFormula = "إِذَا الْتَقَتِ الْوَاوُ أَوِ الْيَاءُ بَعْدَ أَلِفٍ زَائِدَةٍ فِي الْآخِرِ قُلِبَتَا هَمْزَةً",
            indonesianExplanation = "Apabila ada Wau (و) atau Ya (ي) jatuh di akhir kata yang berada langsung setelah Alif tambahan (zaidah), maka Wau/Ya tersebut diubah menjadi Hamzah (ء).",
            exampleBefore = "بِنَايٌ (Binayun), دُعَاوٌ (Du'awun)",
            exampleAfter = "بِنَاءٌ (Binā'un), دُعَاءٌ (Du'ā'un)",
            category = "Naqis & Lafif"
        ),
        IlalRule(
            number = 8,
            name = "Kaidah Ke-8: I'lal bil-Hadzfi (Pembuangan Wau pada Fi'il Mitsal)",
            arabicFormula = "تُحْذَفُ الْوَاوُ مِنَ الْمُضَارِعِ وَالْأَمْرِ إِذَا كَانَتْ بَيْنَ الْفَتْحَةِ وَالْكَسْرَةِ",
            indonesianExplanation = "Wau (و) pada fi'il mitsal wawiy harus dibuang pada bentuk mudhari' dan amr, karena terletak di antara harakat fathah (huruf mudhara'ah) dan kasrah ('ain fi'il) pada wazan يَفْعِلُ.",
            exampleBefore = "يَوْرِثُ (Yawrithu), اِوْرِثْ (Iwrith)",
            exampleAfter = "يَرِثُ (Yarithu), رِثْ (Rith)",
            category = "Mithal"
        ),
        IlalRule(
            number = 9,
            name = "Kaidah Ke-9: Pembuangan Huruf Illah karena Pertemuan Dua Sukun",
            arabicFormula = "إِذَا الْتَقَى سَاكِنَانِ وَكَانَ أَحَدُهُمَا حَرْفَ عِلَّةٍ حُذِفَ حَرْفُ الْعِلَّةِ",
            indonesianExplanation = "Apabila terdapat pertemuan dua huruf sukun (mati) di dalam satu kata, dan salah satu huruf tersebut merupakan huruf illah (Alif, Wau, atau Ya), maka huruf illah tersebut wajib dibuang demi meringankan lisan.",
            exampleBefore = "قَالْنَ (Qālna), بَنَيْنَ (Banayna)",
            exampleAfter = "قُلْنَ (Qulna), بَنَيْنَ (tanpa alif)",
            category = "Ajwaf & Naqis"
        ),
        IlalRule(
            number = 10,
            name = "Kaidah Ke-10: Idgham Dua Huruf Sejenis (Hukum Mudha'af)",
            arabicFormula = "إِذَا الْتَقَى حَرْفَانِ مِنْ جِنْسٍ وَاحِدٍ وَكَانَ الْأَوَّلُ سَاكِنًا وَالثَّانِي مُتَهَرِّكًا أُدْغِمَ الْأَوَّلُ فِي الثَّانِي",
            indonesianExplanation = "Apabila berkumpul dua huruf sejenis dalam satu kata, maka huruf pertama dimasukkan (diidghamkan) ke huruf kedua. Jika huruf pertama hidup, maka harakatnya harus dibuang atau dipindahkan (Naql) lalu disatukan dengan tasydid.",
            exampleBefore = "مَدَدَ (Madada), يَمْدُدُ (Yamdudu)",
            exampleAfter = "مَدَّ (Madda), يَمُدُّ (Yamuddu)",
            category = "Mudha'af"
        ),
        IlalRule(
            number = 11,
            name = "Kaidah Ke-11: Penukaran Wau Menjadi Ya pada Urutan Ke-4 atau Lebih di Akhir setelah Fathah",
            arabicFormula = "إِذَا وَقَعَتِ الْوَاوُ رَابِعَةً فَصَاعِدًا فِي الطَّرَفِ بَعْدَ فَتْحَةٍ قُلِبَتْ يَاءً",
            indonesianExplanation = "Apabila ada huruf Wau (و) menempati urutan keempat atau lebih di ujung akhir kata dan terletak setelah harakat fathah, maka wajib ditukar menjadi Ya (ي).",
            exampleBefore = "يُرْضَوُ (Yurdhawu)",
            exampleAfter = "يُرْضَى (Yurdhā)",
            category = "Naqis"
        ),
        IlalRule(
            number = 12,
            name = "Kaidah Ke-12: Sukun Vokal Akhir (I'lal bit-Taskin)",
            arabicFormula = "تُسَكَّنُ الْوَاوُ وَالْيَاءُ فِي الْآخِرِ تَقْدِيرًا لِلضَّمَّةِ أَوِ الْكَسْرَةِ",
            indonesianExplanation = "Huruf illat Wau (و) atau Ya (ي) di akhir kata disukunkan secara simbolis (Taskin) untuk menolak harakat dhommah atau kasrah yang dinilai terlalu berat dibaca di ujung kata.",
            exampleBefore = "يَبْنِيُ (Yabniyu), يَدْعُوُ (Yad'uwu)",
            exampleAfter = "يَبْنِيْ (Yabnī), يَدْعُوْ (Yad'ū)",
            category = "Naqis & Lafif"
        ),
        IlalRule(
            number = 13,
            name = "Kaidah Ke-13: Penukaran Wau Isim Maf'ul Naqis Menjadi Ya dan Idgham",
            arabicFormula = "إِذَا كَانَ اسْمُ الْمَفْعُولِ مِنَ النَّاقِصِ الْيَائِيِّ قُلِبَتْ وَاوُ مَفْعُولٍ يَاءً وَأُدْغِمَتْ",
            indonesianExplanation = "Apabila isim maf'ul dibentuk dari fi'il naqis ya'iy, maka wau tambahan dari wazan مَفْعُوْل ditukar menjadi Ya (ي), lalu dileburkan (diidghamkan) dengan Ya lam fi'il menjadi Ya bertasydid dhommatain (يٌّ).",
            exampleBefore = "مَبْنُويٌ (Mabnūyun), مَطْوُويٌ (Maṭwūyun)",
            exampleAfter = "مَبْنِيٌّ (Mabniyyun), مَطْوِيٌّ (Maṭwiyyun)",
            category = "Naqis & Lafif"
        ),
        IlalRule(
            number = 14,
            name = "Kaidah Ke-14: Penukaran Ya Menjadi Alif Karena Fathah Terpisah (Masdar Lafif)",
            arabicFormula = "إِذَا كَانَتِ الْيَاءُ مُتَحَرِّكَةً بَعْدَ فَتْحَةٍ مُقَدَّرَةٍ قُلِبَتْ أَلِفًا",
            indonesianExplanation = "Apabila ada huruf Ya berharakat terletak setelah fathah secara representatif (mukaddarah), ditukar menjadi Alif untuk mengalirkan pengucapan masdar.",
            exampleBefore = "طَيَيٌ (Ṭayayun)",
            exampleAfter = "طَيًّا (Ṭayyan - Alif Tanwin)",
            category = "Lafif"
        ),
        IlalRule(
            number = 15,
            name = "Kaidah Ke-15: Pembuangan Wau Maf'ul Pada Isim Maf'ul Ajwaf",
            arabicFormula = "إِذَا الْتَقَى سَاكِنَانِ فِي اسْمِ الْمَفْعُولِ مِنَ الْأَجْوَفِ حُذِفَتْ وَاوُ مَفْعُولٍ",
            indonesianExplanation = "Apabila terkumpul dua sukun didalam isim maf'ul buatan kata ajwaf wawiy atau ya'iy, maka huruf Wau tambahan dari wazan مَفْعُول harus dibuang demi meringankan kata.",
            exampleBefore = "مَقْوُولٌ (Maqwūlun), مَبْيُوعٌ (Mabyū'un)",
            exampleAfter = "مَقُوْلٌ (Maqūlun), مَبِيْعٌ (Mabī'un)",
            category = "Ajwaf"
        ),
        IlalRule(
            number = 16,
            name = "Kaidah Ke-16: Penukaran Wau/Ya Menjadi Alif pada Masdar Ajwaf yang Di-i'lal Madhinya",
            arabicFormula = "تُقْلَبُ الْوَاوُ يَاءً فِي كُلِّ مَصْدَرٍ أُعِلَّتْ عَيْنُ فِعْلِهِ",
            indonesianExplanation = "Setiap masdar dari fi'il yang ain fi'ial madhinya mengalami i'lal, maka huruf Wau pada masdar tersebut diganti menjadi Ya (ي) demi keselarasan harakat sebelumnya.",
            exampleBefore = "قِوَامٌ (Qiwāmun), صِوَامٌ (Ṣiwāmun)",
            exampleAfter = "قِيَامٌ (Qiyāmun), صِيَامٌ (Ṣiyāmun)",
            category = "Ajwaf"
        ),
        IlalRule(
            number = 17,
            name = "Kaidah Ke-17: Ibdal Hamzah Menjadi Huruf Mad (Mahmuz Fa')",
            arabicFormula = "إِذَا الْتَقَتْ هَمْزَتَانِ فِي كَلِمَةٍ وَاحِدَةٍ وَكَانَتِ الْأُولَى مُتَحَرِّكَةً وَالثَّانِيَةُ سَاكِنَةً قُلِبَتِ الثَّانِيَةُ حَرْفَ مَدٍّ",
            indonesianExplanation = "Apabila berkumpul dua Hamzah (ء) dalam satu kata, di mana Hamzah pertama berharakat hidup dan Hamzah kedua mati (sukun), maka Hamzah kedua wajib ditukarkan menjadi huruf mad yang sesuai dengan harakat Hamzah pertama (Fathah -> Alif, Dhommah -> Wau, Kasrah -> Ya).",
            exampleBefore = "أَأْكُلُ (A'kulu), أُأْمِنُ (U'minu)",
            exampleAfter = "آكُلُ / آكَلُ (Ākulu / Ākalu), أُوْمِنُ (Ūminu)",
            category = "Mahmuz"
        ),
        IlalRule(
            number = 18,
            name = "Kaidah Ke-18: Penukaran Huruf illat (Wau/Ya) Menjadi Ta' pada Ifti'al",
            arabicFormula = "إِذَا كَانَتْ فَاءُ افْتِعَالَ وَاوًا أَوْ يَاءً قُلِبَتْ تَاءً وَأُدْغِمَتْ",
            indonesianExplanation = "Apabila fa' fi'il pada wazan اِفْتِعَال berupa huruf illat Wau (و) atau Ya (ي), maka wajib diganti menjadi Ta' (ت), kemudian diidghamkan ke dalam huruf Ta tambahan wazan (تّ).",
            exampleBefore = "اِوْتَقَى (Iwtaqā), اِوْتَصَلَ (Iwtasala)",
            exampleAfter = "اِتَّقَى (Ittaqā), اِتَّصَلَ (Ittasala)",
            category = "Mithal & Lafif"
        ),
        IlalRule(
            number = 19,
            name = "Kaidah Ke-19: Tashil / Pembuangan Hamzah Sima'iy pada Fi'il Amr",
            arabicFormula = "تُحْذَفُ الْهَمْزَةُ سَمَاعًا فِي بَعْضِ الْأَفْعَالِ لِكَثْرَةِ الِاسْتِعْمَالِ",
            indonesianExplanation = "Hamzah dibuang secara sima'iy (sesuai lisan kearaban terdengar) pada fi'il amr tertentu, khususnya 'khudz', 'kul', dan 'mur', semata-mata karena sangat seringnya kata ini digunakan dalam perbincangan harian.",
            exampleBefore = "أُأْكُلْ (U'kul), أُأْخُذْ (U'khudh)",
            exampleAfter = "كُلْ (Kul), خُذْ (Khud)",
            category = "Mahmuz"
        )
    )
}
