package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors - Masterpiece Purple & Golden Accent Theme
val EmeraldPrimary = Color(0xFFB45309) // Luxurious Deep Amber-Gold
val EmeraldSecondary = Color(0xFF7C3AED) // Radiant Royal Purple Accent
val EmeraldTertiary = Color(0xFFD97706) // Rich Royal Gold
val EmeraldBackground = Color(0xFFF5EEFF) // Luxurious soft cream-lavender background
val EmeraldSurface = Color(0xFFFFF7FF) // Soft plum-ivory card surface

// Dark Colors - Imperial Royal Violet & Radiant Luminous Gold
val EmeraldPrimaryDark = Color(0xFFFBBF24) // Radiant Luminous Gold
val EmeraldSecondaryDark = Color(0xFFA78BFA) // Majestic Royal Lavender-Purple Accent
val EmeraldTertiaryDark = Color(0xFFECC974) // Soft Champagne Metallic Gold
val EmeraldBackgroundDark = Color(0xFF140727) // Imperial Deep Cosmic Purple-Night Background
val EmeraldSurfaceDark = Color(0xFF22103E) // Elegant Rich Royal Plum Card Surface

// Accent Colors
val IslamicGold = Color(0xFFECC974) // Metallic Gold Accent
val IslamicAmber = Color(0xFFFBBF24) // Luminous Gold Accent
val SoftGoldCream = Color(0xFFFFF9E6) // Soft pastel gold cream container
val SoftSageTint = Color(0xFFEADBFF) // Soft violet-lavender border tint

