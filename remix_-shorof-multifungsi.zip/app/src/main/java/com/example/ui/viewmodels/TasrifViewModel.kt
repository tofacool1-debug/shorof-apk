package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.AiVerbAnalysis
import com.example.data.api.GeminiApiClient
import com.example.data.models.ArabicVerb
import com.example.data.models.Pronoun
import com.example.data.models.TasrifType
import com.example.data.models.VerbData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

// --- UI States ---

sealed interface AiAnalysisUiState {
    object Idle : AiAnalysisUiState
    object Loading : AiAnalysisUiState
    data class Success(val analysis: AiVerbAnalysis) : AiAnalysisUiState
    data class Error(val message: String) : AiAnalysisUiState
}

data class QuizQuestion(
    val id: Int,
    val questionText: String,
    val questionArabic: String?,
    val options: List<String>,
    val correctAnswer: String,
    val selectedAnswer: String? = null,
    val isCorrect: Boolean? = null
)

data class QuizSessionState(
    val isActive: Boolean = false,
    val isFinished: Boolean = false,
    val questions: List<QuizQuestion> = emptyList(),
    val currentQuestionIndex: Int = 0,
    val score: Int = 0
)

data class TasrifUiState(
    val selectedBab: Int? = null, // null means all
    val searchQuery: String = "",
    val selectedVerb: ArabicVerb? = null,
    val selectedVerbForLughawy: ArabicVerb? = null,
    val activeLughawyTense: TasrifType = TasrifType.MADHI,
    
    // Quiz State
    val quiz: QuizSessionState = QuizSessionState(),
    
    // AI Root Analyzer State
    val aiAnalysisInput: String = "",
    val aiAnalysisState: AiAnalysisUiState = AiAnalysisUiState.Idle
)

class TasrifViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TasrifUiState())
    val uiState: StateFlow<TasrifUiState> = _uiState.asStateFlow()

    // Get list of standard verbs filtered by bab and search query
    val filteredVerbs: List<ArabicVerb>
        get() {
            var list = VerbData.verbs
            val bab = _uiState.value.selectedBab
            if (bab != null) {
                list = list.filter { it.bab == bab }
            }
            val query = _uiState.value.searchQuery.trim()
            if (query.isNotEmpty()) {
                val queryLower = query.lowercase()
                val queryStrippedArabic = stripArabicVowels(query).trim()
                val isArabicQuery = query.any { it in '\u0600'..'\u06FF' }

                list = list.filter { verb ->
                    // 1. Matches Latin / English / Indonesian transliteration or meaning
                    val matchesLatin = verb.meaning.lowercase().contains(queryLower) ||
                            verb.transliteration.lowercase().contains(queryLower) ||
                            verb.root.lowercase().replace(" ", "").replace("-", "").contains(queryLower.replace(" ", "").replace("-", "")) ||
                            (verb.shorofType?.lowercase()?.contains(queryLower) ?: false)

                    if (matchesLatin) return@filter true

                    // 2. Matches Arabic queries with/without tashkeel (Applying I'lal rules & conjugates)
                    if (isArabicQuery && queryStrippedArabic.isNotEmpty()) {
                        val allArabicWords = mutableSetOf<String>()

                        // Basic forms (Masdar, Fa'il, Maf'ul, etc.)
                        allArabicWords.add(verb.madhi)
                        allArabicWords.add(verb.mudhari)
                        allArabicWords.add(verb.masdar)
                        allArabicWords.add(verb.fail)
                        verb.maful?.let { allArabicWords.add(it) }
                        allArabicWords.add(verb.amr)
                        allArabicWords.add(verb.nahy)
                        allArabicWords.add(verb.zaman)
                        allArabicWords.add(verb.makan)
                        verb.alah?.let { allArabicWords.add(it) }
                        verb.sifatMusyabbahah?.let { allArabicWords.add(it) }
                        verb.jamakTaksir?.let { allArabicWords.add(it) }
                        verb.shigotMuntahalJumuk?.let { allArabicWords.add(it) }
                        verb.multipleMasdars?.let { allArabicWords.add(it) }
                        verb.isimTasghir?.let { allArabicWords.add(it) }
                        verb.isimTafdhilMudzakkar?.let { allArabicWords.add(it) }
                        verb.isimTafdhilMuannats?.let { allArabicWords.add(it) }

                        // Raw/unspaced Root (e.g. ن-ص-r)
                        val cleanedRoot = verb.root.replace(" ", "").replace("-", "")
                        allArabicWords.add(cleanedRoot)

                        // Fi'il Madhi Conjugations under Tasrif Lughowi (with all I'lal forms accounted for)
                        allArabicWords.addAll(VerbData.conjugateMadhi(verb.madhi))

                        // Fi'il Mudhari Conjugations (with all I'lal forms accounted for)
                        allArabicWords.addAll(VerbData.conjugateMudhari(verb.mudhari))

                        // Fi'il Amr Conjugations
                        allArabicWords.addAll(VerbData.conjugateAmr(verb.amr))

                        // Fi'il Nahi Conjugations
                        allArabicWords.addAll(VerbData.conjugateNahi(verb.nahy))

                        // Isim Fa'il Conjugations and Broken Plural forms (فُعَّل, فُعَّal, فَعَلَة)
                        allArabicWords.addAll(VerbData.conjugateFailWithPlurals(verb))

                        // Isim Maf'ul / Masdar Noun Conjugations
                        verb.maful?.let { allArabicWords.addAll(VerbData.conjugateNoun(it)) }
                        allArabicWords.addAll(VerbData.conjugateNoun(verb.masdar))

                        // Zaman / Makan / Alah plural and dual states (Shigot Muntahal Jumul under dynamic formulas)
                        allArabicWords.addAll(VerbData.conjugateZamanMakanAlah(verb.zaman, verb.root, false))
                        allArabicWords.addAll(VerbData.conjugateZamanMakanAlah(verb.makan, verb.root, false))
                        verb.alah?.let {
                            allArabicWords.addAll(VerbData.conjugateZamanMakanAlah(it, verb.root, true))
                        }

                        // Tafdhil mudzakkar / muannats conjugates
                        verb.isimTafdhilMudzakkar?.let {
                            allArabicWords.addAll(VerbData.conjugateTafdhilMudzakkar(it))
                        }
                        verb.isimTafdhilMuannats?.let {
                            allArabicWords.addAll(VerbData.conjugateTafdhilMuannats(it))
                        }

                        // Un-i'lalized original word bases (Original unmutated Mauzun/Roots like "قَوَلَ" or "بَنَيَ" - "jangan terpaku dengan wazan")
                        if (verb.id == "ajwaf_1") {
                            allArabicWords.addAll(listOf("قَوَلَ", "يَقْوُلُ", "مَقْوُوْلٌ", "قَوَلْتَ", "قَوَلْنَا", "قَاوِلٌ"))
                        }
                        if (verb.id == "naqis_1") {
                            allArabicWords.addAll(listOf("بَنَيَ", "يَبْنِيُ", "مَبْنُوْيٌ", "بَنَيْتُ", "بَنَوْا", "بَانِيٌ"))
                        }
                        if (verb.id == "lafif_1") {
                            allArabicWords.addAll(listOf("طَوَيَ", "يَطْوِيُ", "مَطْوُوْيٌ", "طَوَيْتُ", "طَاوِيٌ"))
                        }
                        if (verb.id == "lafif_2") {
                            allArabicWords.addAll(listOf("وَقَيَ", "يَوْقِيُ", "مَوْقُوْيٌ", "وَقَيْتُ", "وَاقِيٌ"))
                        }
                        if (verb.id == "mudhaaf_1") {
                            allArabicWords.addAll(listOf("مَدَدَ", "يَمْدُدُ", "مَمْدُوْدٌ", "مَدَدْتُ"))
                        }

                        // Verify if any generated, conjugated, or un-i'lalized form matches the striped query
                        allArabicWords.any { word ->
                            val cleanPart = stripArabicVowels(extractArabicOnly(word)).trim()
                            cleanPart.contains(queryStrippedArabic) || queryStrippedArabic.contains(cleanPart)
                        }
                    } else {
                        false
                    }
                }
            }
            return list
        }

    private fun stripArabicVowels(arabicText: String): String {
        return arabicText.filter { char ->
            char != '\u064E' && char != '\u064F' && char != '\u0650' &&
            char != '\u0652' && char != '\u0651' && char != '\u064B' &&
            char != '\u064C' && char != '\u064D' && char != '\u0670'
        }
    }

    private fun extractArabicOnly(text: String): String {
        return text.split('(', ')', '[', ']', '{', '}', ' ', '/', '、', '，', ',').firstOrNull { part ->
            part.any { it in '\u0600'..'\u06FF' }
        }?.trim() ?: text.trim()
    }

    fun selectBab(bab: Int?) {
        _uiState.update { it.copy(selectedBab = bab) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectVerb(verb: ArabicVerb?) {
        _uiState.update { 
            it.copy(
                selectedVerb = verb,
                selectedVerbForLughawy = verb,
                activeLughawyTense = TasrifType.MADHI
            )
        }
    }

    fun setLughawyTense(tense: TasrifType) {
        _uiState.update { it.copy(activeLughawyTense = tense) }
    }

    fun updateAiInput(input: String) {
        _uiState.update { it.copy(aiAnalysisInput = input) }
    }

    // --- AI Root Analysis Action ---

    fun analyzeRootWithAi() {
        val input = _uiState.value.aiAnalysisInput.trim()
        if (input.isEmpty()) return

        _uiState.update { it.copy(aiAnalysisState = AiAnalysisUiState.Loading) }

        viewModelScope.launch {
            try {
                val result = GeminiApiClient.analyzeVerbRoot(input)
                _uiState.update {
                    it.copy(aiAnalysisState = AiAnalysisUiState.Success(result))
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        aiAnalysisState = AiAnalysisUiState.Error(
                            e.localizedMessage ?: "Gagal mendapatkan analisis dari AI."
                        )
                    )
                }
            }
        }
    }

    fun clearAiAnalysis() {
        _uiState.update {
            it.copy(
                aiAnalysisState = AiAnalysisUiState.Idle,
                aiAnalysisInput = ""
            )
        }
    }

    // --- Dynamic Quiz Actions ---

    fun startNewQuiz() {
        val questions = generateQuizQuestions()
        _uiState.update {
            it.copy(
                quiz = QuizSessionState(
                    isActive = true,
                    isFinished = false,
                    questions = questions,
                    currentQuestionIndex = 0,
                    score = 0
                )
            )
        }
    }

    fun submitAnswer(selectedAnswer: String) {
        val currentState = _uiState.value.quiz
        if (currentState.isFinished || currentState.questions.isEmpty()) return

        val currentIndex = currentState.currentQuestionIndex
        val currentQuestion = currentState.questions[currentIndex]
        val isCorrect = selectedAnswer == currentQuestion.correctAnswer
        
        val updatedQuestions = currentState.questions.toMutableList()
        updatedQuestions[currentIndex] = currentQuestion.copy(
            selectedAnswer = selectedAnswer,
            isCorrect = isCorrect
        )

        val newScore = if (isCorrect) currentState.score + 10 else currentState.score

        _uiState.update {
            it.copy(
                quiz = currentState.copy(
                    questions = updatedQuestions,
                    score = newScore
                )
            )
        }
    }

    fun nextQuestion() {
        val currentState = _uiState.value.quiz
        val nextIndex = currentState.currentQuestionIndex + 1
        
        if (nextIndex >= currentState.questions.size) {
            _uiState.update {
                it.copy(
                    quiz = currentState.copy(
                        isActive = false,
                        isFinished = true
                    )
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    quiz = currentState.copy(
                        currentQuestionIndex = nextIndex
                    )
                )
            }
        }
    }

    fun resetQuiz() {
        _uiState.update {
            it.copy(
                quiz = QuizSessionState()
            )
        }
    }

    private fun generateQuizQuestions(): List<QuizQuestion> {
        val list = VerbData.verbs.shuffled()
        val questionsList = mutableListOf<QuizQuestion>()
        
        // Let's generate 5 diverse questions
        val numQuestions = minOf(5, list.size)
        for (i in 0 until numQuestions) {
            val verb = list[i]
            
            // Randomly select question types representing Sharaf rules
            val type = Random.nextInt(4)
            val question = when (type) {
                0 -> {
                    // Question Type 1: Arabic verb to Indonesian meaning
                    val correctAnswer = verb.meaning
                    val wrongOptions = VerbData.verbs
                        .filter { it.meaning != correctAnswer }
                        .map { it.meaning }
                        .shuffled()
                        .take(3)
                    
                    val options = (wrongOptions + correctAnswer).shuffled()
                    QuizQuestion(
                        id = i,
                        questionText = "Apa padanan arti atau makna bahasa Indonesia dari kata berikut?",
                        questionArabic = "${verb.madhi} - ${verb.mudhari}",
                        options = options,
                        correctAnswer = correctAnswer
                    )
                }
                1 -> {
                    // Question Type 2: Match Fi'il Madhi to Mudhari
                    val correctAnswer = verb.mudhari
                    val wrongOptions = VerbData.verbs
                        .filter { it.mudhari != correctAnswer }
                        .map { it.mudhari }
                        .shuffled()
                        .take(3)
                    
                    val options = (wrongOptions + correctAnswer).shuffled()
                    QuizQuestion(
                        id = i,
                        questionText = "Pilihlah bentuk Fi'il Mudhari yang tepat dari fi'il berikut:",
                        questionArabic = verb.madhi,
                        options = options,
                        correctAnswer = correctAnswer
                    )
                }
                2 -> {
                    // Question Type 3: Match match to Amr (command verb)
                    val correctAnswer = verb.amr
                    val wrongOptions = VerbData.verbs
                        .filter { it.amr != correctAnswer }
                        .map { it.amr }
                        .shuffled()
                        .take(3)
                    
                    val options = (wrongOptions + correctAnswer).shuffled()
                    QuizQuestion(
                        id = i,
                        questionText = "Tentukan bentuk Fi'il Amr (perintah) yang benar dari fi'il berikut:",
                        questionArabic = "${verb.madhi} - ${verb.mudhari}",
                        options = options,
                        correctAnswer = correctAnswer
                    )
                }
                else -> {
                    // Question Type 4: Conjugations pronouns matching (Luqhawy)
                    val pronounsList = Pronoun.values()
                    val selectedPronoun = pronounsList.random()
                    
                    // Let's conjugate and find matching word
                    val conjugatedList = VerbData.conjugateMadhi(verb.madhi)
                    val correctAnswer = conjugatedList[selectedPronoun.ordinal]
                    
                    val otherPronouns = pronounsList.filter { it != selectedPronoun }.shuffled().take(3)
                    val wrongOptions = otherPronouns.map { conjugatedList[it.ordinal] }
                    
                    val options = (wrongOptions + correctAnswer).shuffled()
                    QuizQuestion(
                        id = i,
                        questionText = "Fi'il Madhi dari '${verb.madhi}' untuk kata ganti (Dhomir) [ ${selectedPronoun.dhomir} - ${selectedPronoun.meaningIndo} ] adalah?",
                        questionArabic = null,
                        options = options,
                        correctAnswer = correctAnswer
                    )
                }
            }
            questionsList.add(question)
        }
        return questionsList
    }
}
