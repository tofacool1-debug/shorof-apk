package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimaryDark, // Luminous Gold
    secondary = EmeraldSecondaryDark, // Majestic Royal Lavender-Purple
    tertiary = EmeraldTertiaryDark,
    background = EmeraldBackgroundDark, // Deep Cosmic Purple-Night Background
    surface = EmeraldSurfaceDark, // Elegant Deep Royal Plum Card
    onPrimary = Color(0xFF140727), // Deep dark purple text on gold buttons
    onSecondary = Color(0xFF140727),
    onBackground = Color(0xFFF1E3FF), // Soft light-lavender text
    onSurface = Color(0xFFF1E3FF),
    surfaceVariant = Color(0xFF2E1552), // Medium violet detail backgrounds
    onSurfaceVariant = Color(0xFFE5D5FC),
    outline = Color(0xFFECC974).copy(alpha = 0.4f) // Soft gold outlines
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary, // Luxurious Deep Gold
    secondary = EmeraldSecondary, // Radiant Royal Purple Accent
    tertiary = EmeraldTertiary, // Rich Royal Gold
    background = EmeraldBackground, // Luxurious Soft Lavender Cream
    surface = EmeraldSurface, // Soft Ivory-Purple Card Surface
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF2E0954), // Deep Purple-Black text for crisp readability
    onSurface = Color(0xFF2E0954),
    surfaceVariant = SoftSageTint, // Soft lavender border tint
    onSurfaceVariant = Color(0xFF5D289B), // Royal Violet text variant
    outline = EmeraldSecondary.copy(alpha = 0.3f), // Mild violet outlines
    secondaryContainer = SoftGoldCream, // Pastel gold cream container
    onSecondaryContainer = Color(0xFF78350F) // Gold brown text on secondary container
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve our beautiful crafted Golden Theme branding
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
