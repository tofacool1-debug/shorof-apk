package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.data.api.AiVerbAnalysis
import com.example.ui.viewmodels.AiAnalysisUiState
import com.example.data.models.ArabicVerb
import com.example.data.models.VerbData
import com.example.ui.components.TasrifIstilahyGrid
import com.example.ui.components.TasrifLughawyList
import com.example.ui.components.TasrifIstilahyTable
import com.example.ui.components.QawaidIlalView
import com.example.ui.viewmodels.QuizQuestion
import com.example.ui.viewmodels.TasrifUiState
import com.example.ui.viewmodels.TasrifViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: TasrifViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    
    // Manage local tabs (Kamus = 0, Kuis = 1, AI Root = 2)
    var currentTab by remember { mutableStateOf(0) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. HEADER (Vibrant Islamic Gradient)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    )
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Kamus Sharaf AI",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Pencarian Sistematis Mujarrod & Mazid + Kamus Munawwir",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                        
                        // Small ornamental icon
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = "Buku Tasrif",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
            }

            // 2. SEGMENTED NAVIGATION ROW (Tab Selector)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf(
                    Triple(0, Icons.Default.AutoAwesome, "Kamus AI"),
                    Triple(1, Icons.Default.Quiz, "Latihan Kuis"),
                    Triple(2, Icons.Default.MenuBook, "19 Kaidah")
                )
                
                tabs.forEach { (index, icon, label) ->
                    val isSelected = currentTab == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                            )
                            .clickable { currentTab = index }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // 3. MAIN ACCORDION PANEL / TAB PANEL
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentTab) {
                    0 -> AiTab(viewModel, uiState)
                    1 -> KuisTab(viewModel, uiState)
                    2 -> QawaidIlalView(onVerbClick = { viewModel.selectVerb(it) })
                }
            }
        }

        // 4. OVERLAY DETAIL TRANSITION VIEW (When a verb is clicked in Kamus mode)
        AnimatedVisibility(
            visible = uiState.selectedVerb != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            val verb = uiState.selectedVerb
            if (verb != null) {
                VerbDetailOverlay(
                    verb = verb,
                    activeLughawyTense = uiState.activeLughawyTense,
                    onTenseChange = { viewModel.setLughawyTense(it) },
                    onDismiss = { viewModel.selectVerb(null) }
                )
            }
        }
    }
}

// ==========================================
// TAB 1: KAMUS SHARAF
// ==========================================
@Composable
fun KamusTab(
    viewModel: TasrifViewModel,
    state: TasrifUiState,
    onNavigateToAiTab: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Horizontal Scrollable list of Bab chip selectors
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = state.selectedBab == null,
                    onClick = { viewModel.selectBab(null) },
                    label = { Text("Semua Bab") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        selectedLabelColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
            
            items(6) { idx ->
                val num = idx + 1
                val details = VerbData.BAB_INFO[num]!!
                FilterChip(
                    selected = state.selectedBab == num,
                    onClick = { viewModel.selectBab(num) },
                    label = { 
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Bab $num")
                            Text(details.example, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                        }
                    },
                    modifier = Modifier.height(44.dp)
                )
            }
        }

        // Search Bar
        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Ketik lafadz Arab (Mujarrod/Mazid), akar, arti...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Cari") },
            trailingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Bersihkan")
                        }
                        IconButton(onClick = { onNavigateToAiTab(state.searchQuery) }) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Cari AI & Munawwir", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )



        val list = viewModel.filteredVerbs

        if (list.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Kosong",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (state.searchQuery.isNotEmpty()) "Lafadz \"${state.searchQuery}\" Tidak Ada di Data Lokal" else "Tidak ada kata yang cocok",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = if (state.searchQuery.isNotEmpty()) "Gunakan Pencarian Kamus Sistematis (Mujarrod & Mazid) untuk mengambil arti terjemahan Indonesia lengkap dari Kamus Munawwir & keterangan rujukan kitab." else "Cari lafadz lain atau gunakan Pencarian Sharaf AI.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    
                    if (state.searchQuery.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { onNavigateToAiTab(state.searchQuery) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth(0.8f).height(48.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "AI Search")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Cari Kamus Sistematis AI")
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(list, key = { it.id }) { verb ->
                    VerbListItem(verb = verb, onClick = { viewModel.selectVerb(verb) })
                }
            }
        }
    }
}

@Composable
fun VerbListItem(verb: ArabicVerb, onClick: () -> Unit) {
    var isExpanded by remember { mutableStateOf(false) }
    
    val appliedRules = remember(verb) {
        com.example.data.models.IlalData.RULES.filter { it.isAppliesTo(verb.shorofType ?: "Salim") }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Meaning and Root details
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = verb.meaning,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Text(
                        text = "Akar Kata: ${verb.root}  |  Bab ${verb.bab}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Shorof Type & I'lal Badge FlowRow
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Shorof Type Badge
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = verb.shorofType ?: "Salim",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        // Active I'lal Rules Badge
                        if (appliedRules.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "I'lal: " + appliedRules.joinToString(", ") { "Qoidah ${it.number}" },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Arabic Conjugate (Mauzun) on the Right
                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "${verb.madhi} - ${verb.mudhari}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right
                    )
                    Text(
                        text = verb.transliteration,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline,
                        textAlign = TextAlign.Right
                    )
                }
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Sembunyikan" else "Tampilkan",
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Expanded Area showing the 10 forms table
            if (isExpanded) {
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    TasrifIstilahyTable(
                        bab = verb.bab,
                        madhi = verb.madhi,
                        mudhari = verb.mudhari,
                        masdar = verb.multipleMasdars ?: verb.masdar,
                        fail = verb.fail,
                        sifatMusyabbahah = verb.sifatMusyabbahah,
                        maful = verb.maful ?: "-",
                        amr = verb.amr,
                        nahy = verb.nahy,
                        zaman = verb.zaman,
                        makan = verb.makan,
                        alah = verb.alah,
                        isimTasghir = verb.isimTasghir,
                        isimTafdhilMudzakkar = verb.isimTafdhilMudzakkar,
                        isimTafdhilMuannats = verb.isimTafdhilMuannats
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onClick,
                            colors = ButtonDefaults.textButtonColors(
                                contentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.Apps, contentDescription = "Detail")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Buka Sharaf Lughawy & Kamus Klasik")
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: KUIS LATIHAN INTERAKTIF
// ==========================================
@Composable
fun KuisTab(viewModel: TasrifViewModel, state: TasrifUiState) {
    val quiz = state.quiz

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (!quiz.isActive && !quiz.isFinished) {
            // SCREEN 1: SERAMBI MULAI KUIS
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(128.dp)
                        .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = "Sekolah",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(72.dp)
                    )
                }
                
                Spacer(modifier = Modifier.height(18.dp))
                
                Text(
                    text = "Asah Sharaf Mujarrad Anda",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(6.dp))
                
                Text(
                    text = "Latih kecakapan Anda mendeteksi Bab, perubahan kata (Istilahiy), dan pencocokan dhomir (Lughawy) dalam kuis 5 pertanyaan acak.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                
                Spacer(modifier = Modifier.height(28.dp))
                
                Button(
                    onClick = { viewModel.startNewQuiz() },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Mulai")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Mulai Latihan Kuis", style = MaterialTheme.typography.titleMedium)
                }
            }
        } else if (quiz.isActive && quiz.questions.isNotEmpty()) {
            // SCREEN 2: ACTIVE QUESTION ARENA
            val currentIdx = quiz.currentQuestionIndex
            val question = quiz.questions[currentIdx]
            val isAnswered = question.selectedAnswer != null

            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header progress indicators
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pertanyaan ${currentIdx + 1} dari ${quiz.questions.size}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = "Skor: ${quiz.score}",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                // Progress Bar
                LinearProgressIndicator(
                    progress = (currentIdx + 1).toFloat() / quiz.questions.size,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .clip(CircleShape)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Question Card Text
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = question.questionText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        if (question.questionArabic != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Box(
                                modifier = Modifier
                                    .background(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(vertical = 12.dp, horizontal = 24.dp)
                            ) {
                                Text(
                                    text = question.questionArabic,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Option Choice Buttons
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    question.options.forEach { option ->
                        val isSelectedThis = question.selectedAnswer == option
                        val isCorrect = option == question.correctAnswer
                        
                        val containerColor = when {
                            !isAnswered -> MaterialTheme.colorScheme.surface
                            isSelectedThis && isCorrect -> Color(0xFFE8F5E9) // soft green
                            isSelectedThis && !isCorrect -> Color(0xFFFFEBEE) // soft red
                            isCorrect -> Color(0xFFE8F5E9) // show correct mapping regardless
                            else -> MaterialTheme.colorScheme.surface
                        }

                        val borderColor = when {
                            !isAnswered -> MaterialTheme.colorScheme.outlineVariant
                            isSelectedThis && isCorrect -> Color(0xFF2E7D32)
                            isSelectedThis && !isCorrect -> Color(0xFFC62828)
                            isCorrect -> Color(0xFF2E7D32)
                            else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isAnswered) {
                                    viewModel.submitAnswer(option)
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = containerColor,
                            border = BorderStroke(2.dp, borderColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (isSelectedThis || (isAnswered && isCorrect)) FontWeight.Bold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                
                                if (isAnswered) {
                                    if (isCorrect) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Benar",
                                            tint = Color(0xFF2E7D32)
                                        )
                                    } else if (isSelectedThis) {
                                        Icon(
                                            imageVector = Icons.Default.Cancel,
                                            contentDescription = "Salah",
                                            tint = Color(0xFFC62828)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Footer Actions
                if (isAnswered) {
                    Button(
                        onClick = { viewModel.nextQuestion() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Lanjut")
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = "Selesai")
                    }
                }
            }
        } else {
            // SCREEN 3: QUIZ RESULT SCREEN
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Latihan Selesai!",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Circular Score representation
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${quiz.score}",
                            fontSize = 48.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "POIN",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(18.dp))
                
                val remark = when (quiz.score) {
                    50 -> "Kerja yang bagus! Ayo tingkatkan pencatatan sharaf Anda."
                    40, 30 -> "Good effort! Ingat kembali rumus-rumus vokal Bab."
                    0, 10, 20 -> "Jangan menyerah! Teruskan menyimak tabel ilmu dhomir sharaf."
                    else -> "Mumtaz! Luar biasa! Kemampuan Sharaf Anda sangat baik."
                }
                
                Text(
                    text = remark,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
                
                Spacer(modifier = Modifier.height(30.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(0.9f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.resetQuiz() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Keluar")
                    }
                    Button(
                        onClick = { viewModel.startNewQuiz() },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Ulang")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Coba Lagi")
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: ANALISIS AKAR INTERAKTIF AI
// ==========================================
@Composable
fun AiTab(viewModel: TasrifViewModel, state: TasrifUiState) {
    // Check if API Key is configured in developer secrets
    val isApiKeyPresent = remember {
        val key = BuildConfig.GEMINI_API_KEY
        key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // AI Intro Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Sistem Pencarian Kamus Sharaf AI & Munawwir",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Cari lafadz apa saja (baik Mujarrod maupun Mazid) atau akar kata untuk dianalisis arti Indonesianya berdasarkan Kamus Munawwir serta silsilah sharaf.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Always display Search Bar (Kotak Pencarian Utama)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = state.aiAnalysisInput,
                onValueChange = { viewModel.updateAiInput(it) },
                placeholder = { Text("Contoh: كَتَبَ, اِسْتَغْفَرَ, ك ت ب", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)) },
                shape = RoundedCornerShape(12.dp),
                label = { Text("Lafadz Arab (Mujarod/Mazid) / Akar", color = MaterialTheme.colorScheme.primary) },
                singleLine = true,
                leadingIcon = { 
                    Icon(
                        imageVector = Icons.Default.Search, 
                        contentDescription = "Cari", 
                        tint = MaterialTheme.colorScheme.primary
                    ) 
                },
                trailingIcon = {
                    if (state.aiAnalysisInput.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateAiInput("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear, 
                                contentDescription = "Bersihkan", 
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                    cursorColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.weight(1.8f)
            )
            
            Button(
                onClick = { viewModel.analyzeRootWithAi() },
                shape = RoundedCornerShape(12.dp),
                enabled = state.aiAnalysisState !is AiAnalysisUiState.Loading && state.aiAnalysisInput.isNotEmpty(),
                modifier = Modifier
                    .weight(1.2f)
                    .height(56.dp)
            ) {
                if (state.aiAnalysisState is AiAnalysisUiState.Loading) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("Cari Sharaf")
                }
            }
        }

        if (!isApiKeyPresent) {
            Spacer(modifier = Modifier.height(16.dp))
            // API Key Warning banner
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.82f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = "Peringatan", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Kunci API (GEMINI_API_KEY) Belum Dikonfigurasi",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Aplikasi ini menggunakan teknologi AI Google Gemini cerdas untuk mendeteksi konjugasi. Silahkan masukkan GEMINI_API_KEY Anda di Secrets panel AI Studio untuk mengaktifkan pencarian dinamis.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // AI STATE VIEWPORTS
        when (val result = state.aiAnalysisState) {
            is AiAnalysisUiState.Idle -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Tuliskan lafadz Arab (Mujarrod/Mazid) atau akar kata di atas lalu tekan Cari Sharaf.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
            }
            is AiAnalysisUiState.Loading -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Mencari data & memformulasikan arti (Kamus Munawwir) serta analisis Sharaf...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }
            }
            is AiAnalysisUiState.Success -> {
                val valResult = result.analysis
                AiSuccessCard(analysis = valResult, onExamineConjugations = {
                    // Turn AI success into an ArabicVerb so they can explore it horizontally
                    val mappedVerb = ArabicVerb(
                        id = "ai_${valResult.root}",
                        root = valResult.root,
                        bab = valResult.bab,
                        meaning = valResult.meaning,
                        transliteration = valResult.transliteration,
                        madhi = valResult.madhi,
                        mudhari = valResult.mudhari,
                        masdar = valResult.masdar,
                        fail = valResult.fail,
                        maful = valResult.maful,
                        amr = valResult.amr,
                        nahy = valResult.nahy,
                        zaman = valResult.zaman,
                        makan = valResult.makan,
                        alah = valResult.alah,
                        
                        // Pass new morphological analysis outputs
                        dictionarySources = valResult.dictionarySources,
                        shorofType = valResult.shorofType,
                        asalKataGhoiruSalim = valResult.asalKataGhoiruSalim,
                        sifatMusyabbahah = valResult.sifatMusyabbahah,
                        jamakTaksir = valResult.jamakTaksir,
                        shigotMuntahalJumuk = valResult.shigotMuntahalJumuk,
                        multipleMasdars = valResult.multipleMasdars,
                        isimTasghir = valResult.isimTasghir,
                        isimTafdhilMudzakkar = valResult.isimTafdhilMudzakkar,
                        isimTafdhilMuannats = valResult.isimTafdhilMuannats
                    )
                    viewModel.selectVerb(mappedVerb)
                })
            }
            is AiAnalysisUiState.Error -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Error, contentDescription = "Eror", tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gagal Berdiskusi Dengan AI",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = result.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(
                            onClick = { viewModel.clearAiAnalysis() },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Bersihkan Eror")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiSuccessCard(analysis: AiVerbAnalysis, onExamineConjugations: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HASIL ANALISIS AI",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Bab ${analysis.bab}: ${analysis.babPattern}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                // Words large display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "${analysis.madhi} - ${analysis.mudhari}",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Text(
                    text = "${analysis.transliteration} (Akar: ${analysis.root})",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Arti",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Arti Kata",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = analysis.meaning,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Notes,
                        contentDescription = "Penjelasan",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Keterangan/Penjelasan morfologi",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = analysis.explanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(16.dp))

                // Beautiful structured 10-forms table directly inside the success card!
                Text(
                    text = "TABEL KONJUGASI MORFOLOGI (10 BENTUK)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                TasrifIstilahyTable(
                    bab = analysis.bab,
                    madhi = analysis.madhi,
                    mudhari = analysis.mudhari,
                    masdar = analysis.multipleMasdars.ifEmpty { analysis.masdar },
                    fail = analysis.fail,
                    sifatMusyabbahah = analysis.sifatMusyabbahah,
                    maful = analysis.maful.ifEmpty { "-" },
                    amr = analysis.amr,
                    nahy = analysis.nahy,
                    zaman = analysis.zaman,
                    makan = analysis.makan,
                    alah = analysis.alah,
                    isimTasghir = analysis.isimTasghir,
                    isimTafdhilMudzakkar = analysis.isimTafdhilMudzakkar,
                    isimTafdhilMuannats = analysis.isimTafdhilMuannats
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Unlock Conjugations buttons
                Button(
                    onClick = onExamineConjugations,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Apps, contentDescription = "Tabel")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Lihat Tabel Tasrif Istilahy & Lughawy Lengkap")
                }
            }
        }
    }
}





// ==========================================
// DYNAMIC DETAIL SLIDE-UP SHEET OVERLAY
// ==========================================
@Composable
fun VerbDetailOverlay(
    verb: ArabicVerb,
    activeLughawyTense: com.example.data.models.TasrifType,
    onTenseChange: (com.example.data.models.TasrifType) -> Unit,
    onDismiss: () -> Unit
) {
    var subTabSelection by remember { mutableStateOf(0) } // 0 = Lughawy, 1 = Kamus Klasik

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                    
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${verb.madhi} - ${verb.mudhari}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Bab ${verb.bab}: ${verb.meaning}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                    
                    // Invisible spacer for balance
                    Box(modifier = Modifier.size(48.dp))
                }
            }

            // Tabs controller
            TabRow(
                selectedTabIndex = subTabSelection,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = subTabSelection == 0,
                    onClick = { subTabSelection = 0 },
                    text = { Text("Lughawy (14)", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = subTabSelection == 1,
                    onClick = { subTabSelection = 1 },
                    text = { Text("Kamus Klasik", fontWeight = FontWeight.Bold) }
                )
            }

            // Scrollable view for contents
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Verb Summary Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Akar Kata: ${verb.root}  |  Jenis: ${verb.shorofType ?: "Tsulatsi Mujarrad Salim (Sehat)"}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                when (subTabSelection) {
                    0 -> TasrifLughawyList(
                        verb = verb,
                        activeTense = activeLughawyTense,
                        onTenseChange = onTenseChange
                    )
                    1 -> KamusClassicDetailView(verb = verb)
                }
                
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

fun getImlaAndIlalRules(verb: ArabicVerb): Pair<String, String> {
    val type = verb.shorofType ?: "Salim"
    val lowerType = type.lowercase()
    
    return when {
        lowerType.contains("mithal") || lowerType.contains("mitsal") -> {
            Pair(
                "Masa lampau (Madhi: '${verb.madhi}') ditulis utuh dengan huruf Wau (و) pertama. Pada Fi'il Mudhari ('${verb.mudhari}') dan Amr ('${verb.amr}'), ejaan ditulis lebih ringkas tanpa menyertakan huruf Wau karena wau tersebut dibuang pada rasm khatt.",
                "Terjadi I'lal bil-Hadzfi (حَذْف - pembuangan huruf). Huruf Wau (و) dibuang karena ia adalah fa' fi'il yang jatuh di antara huruf berharakat fathah (huruf mudhara'ah) dan kasrah (ain fi'il) pada Mudhari Ma'lum."
            )
        }
        lowerType.contains("ajwaf") -> {
            Pair(
                "Pada Isim Fa'il ('${verb.fail}'), huruf illah diubah penyalinannya menjadi Hamzah mutawassithah bersandarkan kursi ya' tanpa titik (ئـ) karena berharakat kasrah setelah alif sukun (contoh: قَائِلٌ).",
                "Terjadi I'lal bin-Naqli (نَقْل - pemindahan harakat) dan I'lal bil-Qalbi (قَلْب - penukaran huruf). Harakat huruf illat dipindahkan ke huruf shahih sebelumnya yang mati, lalu huruf illat ditukar menjadi huruf mad (alif/waw/ya) untuk menyelaraskan pengucapan."
            )
        }
        lowerType.contains("naqis") || lowerType.contains("naqish") -> {
            Pair(
                "Alif ditulis tegak (ا) di akhir jika asalnya adalah Wau, dan ditulis berupa Alif Maqshurah (ى) jika asalnya adalah Ya. Pada isim mufrad tanwin (isim fa'il), huruf illah dibuang sehingga ditulis berharakat kasratain (contoh: دَاعٍ).",
                "Terjadi I'lal bil-Qalbi di mana huruf illah di akhir ditukar menjadi Alif karena berharakat fathah sebelumnya. Juga mengalami I'lal bil-Hadzfi saat terdapat pertemuan dua sukun ketika bersambung dengan dhomir jamak kata kerja."
            )
        }
        lowerType.contains("mudha'af") || lowerType.contains("mudaaf") || lowerType.contains("mudhaaf") -> {
            Pair(
                "Dua huruf sejenis yang berurutan disatukan penulisannya berupa satu huruf yang dibubuhi tanda Tasydid ( ّ ) sebagai penanda peleburan vokal konsonan ganda.",
                "Terjadi hukum Idgham (إدغام), yaitu menyatukan huruf sukun pertama ke dalam huruf berharakat kedua yang sejenis. Jika huruf pertama hidup, harakatnya dipindahkan terlebih dahulu (Naql) lalu dileburkan."
            )
        }
        lowerType.contains("mahmuz") -> {
            Pair(
                "Penulisan hamzah (ء) mengikuti rasm Al-Hamzah berdasarkan harakat terkuat (Kaidah Al-Aqwa). Hamzah ditulis di atas Alif, Wau, atau Ya bergantung pada keselarasan harakat pendukungnya.",
                "Dapat mengalami peringan bunyi hamzah (Tashil - تسهيل) atau penggantian hamzah sukun kedua menjadi huruf mad (Ibdal - إبدال) di beberapa dhomir tasrif amr."
            )
        }
        else -> {
            Pair(
                "Ejaan lurus (rasm standar) tanpa pembuangan atau peleburan huruf. Setiap huruf disajikan sesuai makhrijal standar dengan harakat tanda baca lengkap.",
                "Tidak mengalami hukum I'lal, Ibdal, maupun Idgham karena seluruh huruf pembentuk akar kata terdiri dari huruf shahih/sehat yang orisinal dan stabil."
            )
        }
    }
}

@Composable
fun KamusClassicDetailView(verb: ArabicVerb, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Badge & Shorof Type Classification
        val hasAdvDetails = verb.shorofType != null
        
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Title and Classification Badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Klasifikasi Shorof & Asal Kata",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    val typeText = verb.shorofType ?: "Salim (Sehat & Shahih)"
                    val isSalim = typeText.contains("Salim", ignoreCase = true) && !typeText.contains("Ghairu", ignoreCase = true)
                    
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSalim) Color(0xFF2E7D32) else Color(0xFFE65100),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = typeText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Explaining the "Asal Kata jika ghoiru salim"
                Text(
                    text = "Asal-Usul & Mutasi Morfologis:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                
                val originExplanation = verb.asalKataGhoiruSalim 
                    ?: "Kata ini berjenis Fi'il Salim yang sehat dan orisinal. Seluruh huruf penyusunnya berupa huruf asli (shahih) dan tidak mengalami perubahan bentuk, peleburan (idgham), penukaran (ibdal) maupun pembuangan huruf vokal (i'lal)."
                
                Text(
                    text = originExplanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Applied 19 Kaidah I'lal Section
        val appliedRules = remember(verb) {
            com.example.data.models.IlalData.RULES.filter { it.isAppliesTo(verb.shorofType ?: "Salim") }
        }

        if (appliedRules.isNotEmpty()) {
            Text(
                text = "Kaidah I'lal yang Relevan (dari 19 Qoidah):",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )

            appliedRules.forEach { rule ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(MaterialTheme.colorScheme.secondary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = rule.number.toString(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = rule.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = rule.indonesianExplanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Contoh: ${rule.exampleBefore} ➔ ${rule.exampleAfter}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // 1.5. Analisis Qaidah Imla (Ejaan) & Kaidah I'lal (Phonological mutation)
        val (imlaRule, ilalRule) = remember(verb) { getImlaAndIlalRules(verb) }
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
            ),
            border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Spellcheck,
                        contentDescription = "Rasm Imla",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Analisis Qaidah Imla & I'lal Lengkap",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Section Imla
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "imla",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Tata Ejaan / Penulisan Lafadz (Rasm)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = imlaRule,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(14.dp))

                // Section I'lal
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "i'lal",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Hukum Perubahan Harakat & Huruf Penyakit (Illah)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = ilalRule,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }

        // 2. Kamus Arab Terkenal References
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Book,
                        contentDescription = "Kamus",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Kamus Al-Munawwir & Rujukan Kamus Klasik",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Spacer(modifier = Modifier.height(10.dp))
                
                val dictRef = verb.dictionarySources
                    ?: "Lisan al-Arab (لسان العرب) & Al-Mu'jam al-Wasit:\nKata dasar ini melambangkan arti denotatif '${verb.meaning}'. Digunakan secara luas dalam kesusastraan Arab klasik dan teks Al-Qur'an untuk merujuk pada aktivitas tersebut dengan konjugasi Tsulatsi Mujarrad."
                
                Text(
                    text = dictRef,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }

        // 3. Noun derivatives: Sifat Musyabbahah, Jamak Taksir, Shighat Muntahal Jumuk, Multiple Masdar
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Bentuk Jamak & Sifat Deviasi (Isim)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Multiple masdars display
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(
                            text = "Varian Masdar",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "(Kata Benda/Gerund)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Text(
                        text = verb.multipleMasdars ?: verb.masdar,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f)
                    )
                }
                
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                // Sifat Musyabbahah display
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(
                            text = "Sifat Musyabbahah",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "(Kata Sifat Menetap)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Text(
                        text = verb.sifatMusyabbahah ?: "-",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f)
                    )
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                // Jamak Taksir display
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(
                            text = "Jamak Taksir",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "(Plural Tak Beraturan)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Text(
                        text = verb.jamakTaksir ?: "-",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f)
                    )
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                // Shigot Muntahal Jumuk display
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(
                            text = "Muntahal Jumuk",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "(Bentuk Jamak Maksimal)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Text(
                        text = verb.shigotMuntahalJumuk ?: "-",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(2f)
                    )
                }
            }
        }
        
        if (!hasAdvDetails) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Tip: Gunakan pencarian di Tab 'Analisis AI' untuk menyingkap analisis kamus arab lengkap, sifat musyabbahah, & jenis I'lal dari fi'il apa saja secara real-time!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    }
}
