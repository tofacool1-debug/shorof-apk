package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ArabicVerb
import com.example.data.models.Pronoun
import com.example.data.models.TasrifType
import com.example.data.models.VerbData

@Composable
fun TasrifIstilahyGrid(verb: ArabicVerb, modifier: Modifier = Modifier) {
    val items = remember(verb) {
        listOf(
            TasrifIstilahyItem("Fi'il Madhi", "الفعل الماضي", "Keterangan Lampau (Telah)", verb.madhi),
            TasrifIstilahyItem("Fi'il Mudhari", "الفعل المضارع", "Keterangan Sekarang/Akan", verb.mudhari),
            TasrifIstilahyItem("Masdar", "المصدر", "Kata Benda / Gerund", verb.multipleMasdars ?: verb.masdar),
            TasrifIstilahyItem("Isim Fa'il", "اسم الفاعل", "Pelaku / Subjek", if (verb.bab == 5) "-" else verb.fail),
            TasrifIstilahyItem("Isim Musyabbahah", "الصفة المشبهة", "Kata Sifat Karakter Menetap", verb.sifatMusyabbahah ?: if (verb.bab == 5) verb.fail else "-"),
            TasrifIstilahyItem("Isim Maf'ul", "اسم المفعول", "Penderita / Objek", verb.maful),
            TasrifIstilahyItem("Fi'il Amr", "فعل الأمر", "Kata Kerja Perintah", verb.amr),
            TasrifIstilahyItem("Fi'il Nahy", "فعل النهي", "Kata Kerja Larangan", verb.nahy),
            TasrifIstilahyItem("Isim Zaman", "اسم الزمان", "Keterangan Waktu", verb.zaman),
            TasrifIstilahyItem("Isim Makan", "اسم المكان", "Keterangan Tempat", verb.makan),
            TasrifIstilahyItem("Isim Alah", "اسم الآلة", "Alat", verb.alah ?: "-"),
            TasrifIstilahyItem("Isim Tasghir", "اسم التصغير", "Kata Pengecil (Diminutive)", verb.isimTasghir ?: "-"),
            TasrifIstilahyItem("Isim Tafdhil Lk", "اسم التفضيل مذكر", "Komparatif/Superlatif Lk", verb.isimTafdhilMudzakkar ?: "-"),
            TasrifIstilahyItem("Isim Tafdhil Pr", "اسم التفضيل مؤنث", "Komparatif/Superlatif Pr", verb.isimTafdhilMuannats ?: "-")
        )
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Tasrif Istilahy (Perubahan Bentuk Kata)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Grid-like layout (2 cards per row)
        for (i in items.indices step 2) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Left Item
                Box(modifier = Modifier.weight(1f)) {
                    val label = items[i].titleIndo
                    val wazan = getWazanForForm(verb.bab, label, items[i].wordArabic)
                    TasrifIstilahyCard(item = items[i], wazan = wazan)
                }
                
                // Right Item
                Box(modifier = Modifier.weight(1f)) {
                    if (i + 1 < items.size) {
                        val label = items[i + 1].titleIndo
                        val wazan = getWazanForForm(verb.bab, label, items[i + 1].wordArabic)
                        TasrifIstilahyCard(item = items[i + 1], wazan = wazan)
                    } else {
                        Spacer(modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

data class TasrifIstilahyItem(
    val titleIndo: String,
    val titleArabic: String,
    val description: String,
    val wordArabic: String
)

@Composable
fun TasrifIstilahyCard(item: TasrifIstilahyItem, wazan: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.titleIndo,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = item.titleArabic,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
            
            Spacer(modifier = Modifier.height(10.dp))
            
            // Arabic Word Box - clearly labeled as "Lafadz"
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Lafadz:",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = item.wordArabic,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Wazan details
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Wazan: ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = wazan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasrifLughawyList(
    verb: ArabicVerb,
    activeTense: TasrifType,
    onTenseChange: (TasrifType) -> Unit,
    modifier: Modifier = Modifier
) {
    val pronouns = remember { Pronoun.values() }

    // Resolve what kind of data we display (Verb Pronoun vs Noun Declension)
    val isVerb = activeTense == TasrifType.MADHI || activeTense == TasrifType.MUDHARI || activeTense == TasrifType.AMR || activeTense == TasrifType.NAHY
    val isZamanMakanAlah = activeTense == TasrifType.ZAMAN || activeTense == TasrifType.MAKAN || activeTense == TasrifType.ALAH

    val rowsData = remember(verb, activeTense) {
        when (activeTense) {
            TasrifType.MADHI -> {
                val words = VerbData.conjugateMadhi(verb.madhi)
                pronouns.mapIndexed { idx, pronoun ->
                    LughawyRowItem(pronoun.dhomir, pronoun.meaningIndo, words.getOrNull(idx) ?: "-")
                }
            }
            TasrifType.MUDHARI -> {
                val words = VerbData.conjugateMudhari(verb.mudhari)
                pronouns.mapIndexed { idx, pronoun ->
                    LughawyRowItem(pronoun.dhomir, pronoun.meaningIndo, words.getOrNull(idx) ?: "-")
                }
            }
            TasrifType.AMR -> {
                val words = VerbData.conjugateAmr(verb.amr)
                // Amr only conjugates for 2nd person (ANTA to ANTUNNA)
                pronouns.toList().subList(6, 12).mapIndexed { idx, pronoun ->
                    LughawyRowItem(pronoun.dhomir, pronoun.meaningIndo, words.getOrNull(idx) ?: "-")
                }
            }
            TasrifType.NAHY -> {
                val words = VerbData.conjugateNahi(verb.nahy)
                // Prohibitive (Nahi) only conjugates for 2nd person (ANTA to ANTUNNA)
                pronouns.toList().subList(6, 12).mapIndexed { idx, pronoun ->
                    LughawyRowItem(pronoun.dhomir, pronoun.meaningIndo, words.getOrNull(idx) ?: "-")
                }
            }
            TasrifType.FAIL -> {
                val baseWord = if (verb.bab == 5) "-" else verb.fail
                if (baseWord.isBlank() || baseWord == "-") {
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فُعَّل)", "Jamak Pecah Laki-laki (فُعَّل)", "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فُعَّال)", "Jamak Pecah Laki-laki (فُعَّال)", "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فَعَلَة)", "Jamak Pecah Laki-laki (فَعَلَة)", "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", "-")
                    )
                } else {
                    val words = VerbData.conjugateFailWithPlurals(verb)
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", words.getOrNull(0) ?: "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", words.getOrNull(1) ?: "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", words.getOrNull(2) ?: "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فُعَّل)", "Jamak Pecah Laki-laki (فُعَّل)", words.getOrNull(3) ?: "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فُعَّال)", "Jamak Pecah Laki-laki (فُعَّال)", words.getOrNull(4) ?: "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير - فَعَلَة)", "Jamak Pecah Laki-laki (فَعَلَة)", words.getOrNull(5) ?: "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", words.getOrNull(6) ?: "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", words.getOrNull(7) ?: "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", words.getOrNull(8) ?: "-")
                    )
                }
            }
            TasrifType.SIFAT_MUSYABBAHAH -> {
                val baseWord = if (verb.bab == 5) {
                    if (verb.sifatMusyabbahah.isNullOrBlank() || verb.sifatMusyabbahah == "-") verb.fail else verb.sifatMusyabbahah
                } else {
                    verb.sifatMusyabbahah ?: "-"
                }
                if (baseWord.isBlank() || baseWord == "-") {
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", "-")
                    )
                } else {
                    val words = VerbData.conjugateNoun(baseWord)
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", words.getOrNull(0) ?: "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", words.getOrNull(1) ?: "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", words.getOrNull(2) ?: "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", words.getOrNull(3) ?: "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", words.getOrNull(4) ?: "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", words.getOrNull(5) ?: "-")
                    )
                }
            }
            TasrifType.MAFUL -> {
                val words = VerbData.conjugateNoun(verb.maful)
                listOf(
                    LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", words.getOrNull(0) ?: "-"),
                    LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", words.getOrNull(1) ?: "-"),
                    LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", words.getOrNull(2) ?: "-"),
                    LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", words.getOrNull(3) ?: "-"),
                    LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", words.getOrNull(4) ?: "-"),
                    LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", words.getOrNull(5) ?: "-")
                )
            }
            TasrifType.ZAMAN -> {
                val words = VerbData.conjugateZamanMakanAlah(verb.zaman, verb.root, false)
                listOf(
                    LughawyRowItem("Mufrad (مفرد)", "Tunggal (Satu Waktu)", words.getOrNull(0) ?: "-"),
                    LughawyRowItem("Tatsniyah (تثنية)", "Dual (Dua Waktu)", words.getOrNull(1) ?: "-"),
                    LughawyRowItem("Jamak Taksir (جمع تكسير)", "Jamak Pecah / Muntahal Jumuk", words.getOrNull(2) ?: "-")
                )
            }
            TasrifType.MAKAN -> {
                val words = VerbData.conjugateZamanMakanAlah(verb.makan, verb.root, false)
                listOf(
                    LughawyRowItem("Mufrad (مفرد)", "Tunggal (Satu Tempat)", words.getOrNull(0) ?: "-"),
                    LughawyRowItem("Tatsniyah (تثنية)", "Dual (Dua Tempat)", words.getOrNull(1) ?: "-"),
                    LughawyRowItem("Jamak Taksir (جمع تكسير)", "Jamak Pecah / Muntahal Jumuk", words.getOrNull(2) ?: "-")
                )
            }
            TasrifType.ALAH -> {
                if (verb.alah == null || verb.alah == "-") {
                    listOf(
                        LughawyRowItem("Mufrad (مفرد)", "Tidak digunakan untuk kata ini", "-"),
                        LughawyRowItem("Tatsniyah (تثنية)", "-", "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير)", "-", "-")
                    )
                } else {
                    val words = VerbData.conjugateZamanMakanAlah(verb.alah, verb.root, true)
                    listOf(
                        LughawyRowItem("Mufrad (مفرد)", "Tunggal (Satu Alat)", words.getOrNull(0) ?: "-"),
                        LughawyRowItem("Tatsniyah (تثنية)", "Dual (Dua Alat)", words.getOrNull(1) ?: "-"),
                        LughawyRowItem("Jamak Taksir (جمع تكسير)", "Jamak Pecah / Muntahal Jumuk", words.getOrNull(2) ?: "-")
                    )
                }
            }
            TasrifType.TASGHIR -> {
                val baseWord = verb.isimTasghir ?: "-"
                if (baseWord.isBlank() || baseWord == "-") {
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", "-")
                    )
                } else {
                    val words = VerbData.conjugateNoun(baseWord)
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal Laki-laki", words.getOrNull(0) ?: "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual Laki-laki", words.getOrNull(1) ?: "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak Laki-laki", words.getOrNull(2) ?: "-"),
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal Perempuan", words.getOrNull(3) ?: "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual Perempuan", words.getOrNull(4) ?: "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak Perempuan", words.getOrNull(5) ?: "-")
                    )
                }
            }
            TasrifType.TAFDHIL_MUDZAKKAR -> {
                val input = verb.isimTafdhilMudzakkar ?: "-"
                if (input == "-" || input.isBlank()) {
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal", "-"),
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual", "-"),
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak", "-")
                    )
                } else {
                    val words = VerbData.conjugateTafdhilMudzakkar(input)
                    listOf(
                        LughawyRowItem("Mufrad Mudzakkar (مفرد مذكر)", "Tunggal (Lebih/Paling ... Lk)", words.getOrNull(0) ?: "-"), 
                        LughawyRowItem("Tatsniyah Mudzakkar (تثنية مذكر)", "Dual (Dua Orang Lebih ... Lk)", words.getOrNull(1) ?: "-"), 
                        LughawyRowItem("Jamak Mudzakkar (جمع مذكر)", "Jamak (Banyak Orang Lebih ... Lk)", words.getOrNull(2) ?: "-") 
                    )
                }
            }
            TasrifType.TAFDHIL_MUANNATS -> {
                val input = verb.isimTafdhilMuannats ?: "-"
                if (input == "-" || input.isBlank()) {
                    listOf(
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal", "-"),
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual", "-"),
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak", "-")
                    )
                } else {
                    val words = VerbData.conjugateTafdhilMuannats(input)
                    listOf(
                        LughawyRowItem("Mufrad Muannats (مفرد مؤنث)", "Tunggal (Lebih/Paling ... Pr)", words.getOrNull(0) ?: "-"), 
                        LughawyRowItem("Tatsniyah Muannats (تثنية مؤنث)", "Dual (Dua Orang Lebih ... Pr)", words.getOrNull(1) ?: "-"), 
                        LughawyRowItem("Jamak Muannats (جمع مؤنث)", "Jamak (Banyak Orang Lebih ... Pr)", words.getOrNull(2) ?: "-") 
                    )
                }
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Tasrif Lughawy (Deklinasi Berdasarkan Kata Ganti & Jumlah)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        val formsList = remember(verb) {
            mutableListOf(
                TasrifType.MADHI to "Fi'il Madhi",
                TasrifType.MUDHARI to "Fi'il Mudhari",
                TasrifType.AMR to "Fi'il Amr",
                TasrifType.NAHY to "Fi'il Nahy",
                TasrifType.FAIL to "Isim Fa'il"
            ).apply {
                if (verb.bab == 5 || !verb.sifatMusyabbahah.isNullOrBlank()) {
                    add(TasrifType.SIFAT_MUSYABBAHAH to "Isim Musyabbahah")
                }
                add(TasrifType.MAFUL to "Isim Maf'ul")
                add(TasrifType.ZAMAN to "Isim Zaman")
                add(TasrifType.MAKAN to "Isim Makan")
                add(TasrifType.ALAH to "Isim Alah")
                if (!verb.isimTasghir.isNullOrBlank() && verb.isimTasghir != "-") {
                    add(TasrifType.TASGHIR to "Isim Tasghir")
                }
                if (!verb.isimTafdhilMudzakkar.isNullOrBlank() && verb.isimTafdhilMudzakkar != "-") {
                    add(TasrifType.TAFDHIL_MUDZAKKAR to "Isim Tafdhil Lk")
                }
                if (!verb.isimTafdhilMuannats.isNullOrBlank() && verb.isimTafdhilMuannats != "-") {
                    add(TasrifType.TAFDHIL_MUANNATS to "Isim Tafdhil Pr")
                }
            }
        }

        // LazyRow of selection chips with full-height scrollability
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(formsList) { (type, label) ->
                val isSelected = activeTense == type
                FilterChip(
                    selected = isSelected,
                    onClick = { onTenseChange(type) },
                    label = { Text(text = label, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }

        // Info cards depending on selection

        if (activeTense == TasrifType.AMR) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Catatan: Fi'il Amr (Kata Kerja Perintah) hanya digunakan untuk Dhomir Mukhotob (Orang Kedua - Kamu/Kalian).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else if (activeTense == TasrifType.NAHY) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Catatan: Fi'il Nahy (Kata Kerja Larangan) hanya digunakan untuk Dhomir Mukhotob (Orang Kedua - Kamu/Kalian).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else if (activeTense == TasrifType.FAIL && verb.bab == 5) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Catatan: Bab 5 tidak memiliki Isim Fa'il standar karena merupakan kata kerja keadaan. Silakan pilih tab Isim Musyabbahah untuk melihat kata sifatnya.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else if (activeTense == TasrifType.SIFAT_MUSYABBAHAH) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Catatan: Isim Musyabbahah digunakan untuk menyatakan sifat atau karakter manusia / benda yang menetap / semi-menetap.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else if (isZamanMakanAlah) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                ),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Text(
                    text = "Catatan: Isim Zaman, Makan, dan Alah digolongkan sebagai Isim. Memiliki bentuk Tunggal (Mufrad), Dua (Tatsniyah), dan Jamak Taksir (pecah) berpola Muntahal Jumuk.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Table Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                .padding(vertical = 10.dp, horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isVerb) "Dhomir (Kata Ganti)" else "Klasifikasi Isim",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.weight(1.6f)
            )
            Text(
                text = "Keterangan",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                modifier = Modifier.weight(1.4f)
            )
            Text(
                text = "Lafadz Tafsir Lughawy",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                textAlign = TextAlign.Right,
                modifier = Modifier.weight(2f)
            )
        }

        // Table Body list
        Surface(
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                rowsData.forEachIndexed { index, item ->
                    val isEven = index % 2 == 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                if (isEven) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant.copy(
                                    alpha = 0.2f
                                )
                            )
                            .padding(vertical = 12.dp, horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left block: label & classification description
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(
                                text = item.label,
                                fontSize = if (isVerb) 18.sp else 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Right block: Arabic word & dynamic Indonesian translation (Arti Lughowi)
                        Column(
                            modifier = Modifier.weight(2.2f),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = item.word,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Right
                            )
                            if (item.word != "-" && item.word.isNotBlank()) {
                                Spacer(modifier = Modifier.height(2.dp))
                                val indonesianTranslation = getLughawyTranslation(verb.meaning, activeTense, index)
                                Text(
                                    text = indonesianTranslation,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.secondary,
                                    textAlign = TextAlign.Right
                                )
                            }
                        }
                    }
                    if (index < rowsData.size - 1) {
                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

fun getLughawyTranslation(baseMeaning: String, tense: TasrifType, index: Int): String {
    val cleanMeaning = baseMeaning.split("/").firstOrNull()?.trim() ?: baseMeaning
    val lowerMeaning = cleanMeaning.lowercase()
    
    // Convert active verbs into passive forms for Maf'ul (e.g., "menolong" -> "ditolong")
    val passiveMeaning = when {
        lowerMeaning.startsWith("me") -> {
            if (lowerMeaning.startsWith("meny")) {
                "di" + lowerMeaning.substring(4)
            } else if (lowerMeaning.startsWith("men")) {
                "di" + lowerMeaning.substring(3)
            } else if (lowerMeaning.startsWith("mem")) {
                "di" + lowerMeaning.substring(3)
            } else if (lowerMeaning.startsWith("meng")) {
                "di" + lowerMeaning.substring(4)
            } else {
                "di" + lowerMeaning.substring(2)
            }
        }
        else -> "di$lowerMeaning"
    }

    return when (tense) {
        TasrifType.MADHI -> {
            val prefix = when (index) {
                0 -> "Dia (1 Lk) telah"
                1 -> "Mereka Berdua (2 Lk) telah"
                2 -> "Mereka (Lk Banyak) telah"
                3 -> "Dia (1 Pr) telah"
                4 -> "Mereka Berdua (2 Pr) telah"
                5 -> "Mereka (Pr Banyak) telah"
                6 -> "Kamu (1 Lk) telah"
                7 -> "Kamu Berdua (L/P) telah"
                8 -> "Kalian (Lk Banyak) telah"
                9 -> "Kamu (1 Pr) telah"
                10 -> "Kamu Berdua (L/P) telah"
                11 -> "Kalian (Pr Banyak) telah"
                12 -> "Saya telah"
                13 -> "Kami/Kita telah"
                else -> "Telah"
            }
            "$prefix $lowerMeaning"
        }
        TasrifType.MUDHARI -> {
            val prefix = when (index) {
                0 -> "Dia (1 Lk) sedang/akan"
                1 -> "Mereka Berdua (2 Lk) sedang/akan"
                2 -> "Mereka (Lk Banyak) sedang/akan"
                3 -> "Dia (1 Pr) sedang/akan"
                4 -> "Mereka Berdua (2 Pr) sedang/akan"
                5 -> "Mereka (Pr Banyak) sedang/akan"
                6 -> "Kamu (1 Lk) sedang/akan"
                7 -> "Kamu Berdua (L/P) sedang/akan"
                8 -> "Kalian (Lk Banyak) sedang/akan"
                9 -> "Kamu (1 Pr) sedang/akan"
                10 -> "Kamu Berdua (L/P) sedang/akan"
                11 -> "Kalian (Pr Banyak) sedang/akan"
                12 -> "Saya sedang/akan"
                13 -> "Kami/Kita sedang/akan"
                else -> "Sedang/akan"
            }
            "$prefix $lowerMeaning"
        }
        TasrifType.AMR -> {
            val baseCommand = when {
                lowerMeaning.contains("tolong") -> "Tolonglah!"
                lowerMeaning.contains("tulis") -> "Tuliskanlah!"
                lowerMeaning.contains("masuk") -> "Masuklah!"
                lowerMeaning.contains("keluar") -> "Keluarlah!"
                lowerMeaning.contains("sujud") -> "Bersujudlah!"
                lowerMeaning.contains("pukul") -> "Pukullah!"
                lowerMeaning.contains("duduk") -> "Duduklah!"
                lowerMeaning.contains("cuci") -> "Cucilah!"
                lowerMeaning.contains("kenal") -> "Kenalilah!"
                lowerMeaning.contains("kembali") -> "Kembalilah!"
                lowerMeaning.contains("buka") -> "Bukalah!"
                lowerMeaning.contains("utus") -> "Utuslah!"
                lowerMeaning.contains("minum") -> "Minumlah!"
                lowerMeaning.contains("paham") -> "Pahamilah!"
                lowerMeaning.contains("hafal") -> "Hafalkanlah!"
                lowerMeaning.contains("dengar") -> "Dengarlah!"
                lowerMeaning.contains("besar") -> "Jadilah besar!"
                lowerMeaning.contains("baik") -> "Jadilah baik!"
                lowerMeaning.contains("kecil") -> "Jadilah kecil!"
                else -> "Lakukanlah $lowerMeaning!"
            }
            when (index) {
                0 -> "$baseCommand (Kamu 1 Lk)"
                1 -> "Kalian Berdua, $baseCommand"
                2 -> "Kalian Banyak Lk, $baseCommand"
                3 -> "$baseCommand (Kamu 1 Pr)"
                4 -> "Kalian Berdua, $baseCommand"
                5 -> "Kalian Banyak Pr, $baseCommand"
                else -> baseCommand
            }
        }
        TasrifType.NAHY -> {
            val baseForbidden = when {
                lowerMeaning.contains("tolong") -> "Jangan menolong!"
                lowerMeaning.contains("tulis") -> "Jangan menulis!"
                lowerMeaning.contains("masuk") -> "Jangan masuk!"
                lowerMeaning.contains("keluar") -> "Jangan keluar!"
                lowerMeaning.contains("sujud") -> "Jangan bersujud!"
                lowerMeaning.contains("pukul") -> "Jangan memukul!"
                lowerMeaning.contains("duduk") -> "Jangan duduk!"
                lowerMeaning.contains("cuci") -> "Jangan mencuci!"
                lowerMeaning.contains("kenal") -> "Jangan mengenal!"
                lowerMeaning.contains("kembali") -> "Jangan kembali!"
                lowerMeaning.contains("buka") -> "Jangan membuka!"
                lowerMeaning.contains("utus") -> "Jangan mengutus!"
                lowerMeaning.contains("minum") -> "Jangan meminum!"
                lowerMeaning.contains("paham") -> "Jangan memahami!"
                lowerMeaning.contains("hafal") -> "Jangan menghafal!"
                lowerMeaning.contains("dengar") -> "Jangan mendengar!"
                lowerMeaning.contains("besar") -> "Jangan membesar!"
                lowerMeaning.contains("baik") -> "Jangan membaik!"
                lowerMeaning.contains("kecil") -> "Jangan mengecil!"
                else -> "Jangan lakukan $lowerMeaning!"
            }
            when (index) {
                0 -> "$baseForbidden (Kamu 1 Lk)"
                1 -> "Kalian Berdua, $baseForbidden"
                2 -> "Kalian Banyak Lk, $baseForbidden"
                3 -> "$baseForbidden (Kamu 1 Pr)"
                4 -> "Kalian Berdua, $baseForbidden"
                5 -> "Kalian Banyak Pr, $baseForbidden"
                else -> baseForbidden
            }
        }
        TasrifType.FAIL -> {
            val prefix = when (index) {
                0 -> "Lk Tunggal: Pelaku yang"
                1 -> "Lk Tatsniyah: Dua pelaku yang"
                2 -> "Lk Jamak: Banyak pelaku yang"
                3 -> "Para pelaku (Jamak Taksir - فُعَّل) yang"
                4 -> "Para pelaku (Jamak Taksir - فُعَّال) yang"
                5 -> "Para pelaku (Jamak Taksir - فَعَلَة) yang"
                6 -> "Pr Tunggal: Pelaku perempuan yang"
                7 -> "Pr Tatsniyah: Dua pelaku perempuan yang"
                8 -> "Pr Jamak: Banyak pelaku perempuan yang"
                else -> "Pihak yang"
            }
            "$prefix $lowerMeaning"
        }
        TasrifType.SIFAT_MUSYABBAHAH -> {
            val prefix = when (index) {
                0 -> "Tunggal Lk: Berkarakter"
                1 -> "Dual Lk: Berkarakter"
                2 -> "Jamak Lk: Berkarakter"
                3 -> "Tunggal Pr: Berkarakter"
                4 -> "Dual Pr: Berkarakter"
                5 -> "Jamak Pr: Berkarakter"
                else -> "Karakter"
            }
            "$prefix $lowerMeaning"
        }
        TasrifType.MAFUL -> {
            val prefix = when (index) {
                0 -> "Tunggal Lk: Objek yang"
                1 -> "Dual Lk: Objek yang"
                2 -> "Jamak Lk: Objek yang"
                3 -> "Tunggal Pr: Objek yang"
                4 -> "Dual Pr: Objek yang"
                5 -> "Jamak Pr: Objek yang"
                else -> "Yang dikenai"
            }
            "$prefix $passiveMeaning"
        }
        TasrifType.ZAMAN -> {
            val obj = lowerMeaning.replace("me", "").replace("men", "").trim()
            when (index) {
                0 -> "Mufrad: Waktu terjadinya $obj"
                1 -> "Tatsniyah: Dua waktu terjadinya $obj"
                2 -> "Jamak Taksir: Macam-macam waktu terjadinya $obj"
                else -> "Waktu $obj"
            }
        }
        TasrifType.MAKAN -> {
            val obj = lowerMeaning.replace("me", "").replace("men", "").trim()
            when (index) {
                0 -> "Mufrad: Tempat terjadinya $obj"
                1 -> "Tatsniyah: Dua tempat terjadinya $obj"
                2 -> "Jamak Taksir: Macam-macam tempat terjadinya $obj"
                else -> "Tempat $obj"
            }
        }
        TasrifType.ALAH -> {
            val obj = lowerMeaning.replace("me", "").replace("men", "").trim()
            when (index) {
                0 -> "Mufrad: Satu unit alat untuk $obj"
                1 -> "Tatsniyah: Dua unit alat untuk $obj"
                2 -> "Jamak Taksir: Macam-macam alat untuk $obj"
                else -> "Alat $obj"
            }
        }
        TasrifType.TASGHIR -> {
            when (index) {
                0 -> "Tunggal Lk: Versi penyayang dari $lowerMeaning"
                1 -> "Dual Lk: Versi penyayang dari $lowerMeaning"
                2 -> "Jamak Lk: Versi penyayang dari $lowerMeaning"
                3 -> "Tunggal Pr: Versi penyayang dari $lowerMeaning"
                4 -> "Dual Pr: Versi penyayang dari $lowerMeaning"
                5 -> "Jamak Pr: Versi penyayang dari $lowerMeaning"
                else -> "Bentuk tasghir"
            }
        }
        TasrifType.TAFDHIL_MUDZAKKAR -> {
            when (index) {
                0 -> "Tunggal Lk: Lebih/Sangat $lowerMeaning"
                1 -> "Dual Lk: Dua pelaku lebih/sangat $lowerMeaning"
                2 -> "Jamak Lk: Banyak pelaku lebih/sangat $lowerMeaning"
                else -> "Lebih/Sangat $lowerMeaning"
            }
        }
        TasrifType.TAFDHIL_MUANNATS -> {
            when (index) {
                0 -> "Tunggal Pr: Lebih/Sangat $lowerMeaning"
                1 -> "Dual Pr: Dua pelaku lebih/sangat $lowerMeaning"
                2 -> "Jamak Pr: Banyak pelaku lebih/sangat $lowerMeaning"
                else -> "Lebih/Sangat $lowerMeaning"
            }
        }
    }
}

data class LughawyRowItem(
    val label: String,
    val description: String,
    val word: String
)

fun extractArabicOnly(text: String): String {
    return text.split('(', ')', '[', ']', '{', '}', ' ', '/', '、', '，', ',').firstOrNull { part ->
        part.any { it in '\u0600'..'\u06FF' }
    }?.trim() ?: text.trim()
}

fun stripArabicVowels(arabicText: String): String {
    return arabicText.filter { char ->
        char != '\u064E' && char != '\u064F' && char != '\u0650' &&
        char != '\u0652' && char != '\u0651' && char != '\u064B' &&
        char != '\u064C' && char != '\u064D' && char != '\u0670'
    }
}

fun getWazanForForm(bab: Int, formNameIndo: String, word: String = ""): String {
    val cleanName = formNameIndo.trim()
    return when {
        cleanName.contains("Madhi") -> when (bab) {
            1 -> "فَعَلَ"
            2 -> "فَعَلَ"
            3 -> "فَعَلَ"
            4 -> "فَعِلَ"
            5 -> "فَعُلَ"
            6 -> "فَعِلَ"
            else -> "فَعَلَ"
        }
        cleanName.contains("Mudhari") -> when (bab) {
            1 -> "يَفْعُلُ"
            2 -> "يَفْعِلُ"
            3 -> "يَفْعَلُ"
            4 -> "يَفْعَلُ"
            5 -> "يَفْعُلُ"
            6 -> "يَفْعِلُ"
            else -> "يَفْعُلُ"
        }
        cleanName.contains("Masdar") -> when (bab) {
            1 -> "فَعْلًا"
            2 -> "فَعْلًا"
            3 -> "فَعْلًا"
            4 -> "فُعْلًا"
            5 -> "فُعْلًا"
            6 -> "فُعْلَانًا"
            else -> "فَعْلًا"
        }
        cleanName.contains("Fa'il") || cleanName.contains("Musyabbahah") || cleanName.contains("Sifat") -> {
            val cleanWord = extractArabicOnly(word)
            val consonants = stripArabicVowels(cleanWord)
            when {
                word == "-" || word.isBlank() -> "-"
                consonants.getOrNull(1) == 'ا' || consonants.getOrNull(1) == '\u0627' -> "فَاعِلٌ"
                consonants.getOrNull(2) == 'ي' || consonants.getOrNull(2) == '\u064A' -> "فَعِيْلٌ"
                consonants == "حسن" -> "فَعَلٌ"
                else -> "سَمَاعِيّ"
            }
        }
        cleanName.contains("Maf'ul") -> {
            if (bab == 5) "سَمَاعِيّ" else "مَفْعُوْلٌ"
        }
        cleanName.contains("Amr") -> when (bab) {
            1 -> "اُفْعُلْ"
            2 -> "اِفْعِلْ"
            3 -> "اِفْعَلْ"
            4 -> "اِفْعَلْ"
            5 -> "اُفْعُلْ"
            6 -> "اِفْعِلْ"
            else -> "اُفْعُلْ"
        }
        cleanName.contains("Nahy") -> when (bab) {
            1 -> "لَا تَفْعُلْ"
            2 -> "لَا تَفْعِلْ"
            3 -> "لَا تَفْعَلْ"
            4 -> "لَا تَفْعَلْ"
            5 -> "لَا تَفْعُلْ"
            6 -> "لَا تَفْعِلْ"
            else -> "لَا تَفْعُلْ"
        }
        cleanName.contains("Zaman") -> when (bab) {
            2, 6 -> "مَفْعِلٌ"
            else -> "مَفْعَلٌ"
        }
        cleanName.contains("Makan") -> when (bab) {
            2, 6 -> "مَفْعِلٌ"
            else -> "مَفْعَلٌ"
        }
        cleanName.contains("Alah") -> when (bab) {
            5, 6 -> "-"
            else -> "مِفْعَلٌ"
        }
        cleanName.contains("Tasghir") -> "فُعَيْلٌ"
        cleanName.contains("Tafdhil Lk") || cleanName.contains("Tafdhil (Lk)") || cleanName.contains("Tafdhil Mudzakkar") -> "أَفْعَلُ"
        cleanName.contains("Tafdhil Pr") || cleanName.contains("Tafdhil (Pr)") || cleanName.contains("Tafdhil Muannats") -> "فُعْلَىٰ"
        else -> "-"
    }
}

@Composable
fun TasrifIstilahyTable(
    bab: Int,
    madhi: String,
    mudhari: String,
    masdar: String,
    fail: String,
    sifatMusyabbahah: String?,
    maful: String,
    amr: String,
    nahy: String,
    zaman: String,
    makan: String,
    alah: String?,
    isimTasghir: String? = null,
    isimTafdhilMudzakkar: String? = null,
    isimTafdhilMuannats: String? = null,
    modifier: Modifier = Modifier
) {
    val items = remember(madhi, mudhari, masdar, fail, sifatMusyabbahah, maful, amr, nahy, zaman, makan, alah, isimTasghir, isimTafdhilMudzakkar, isimTafdhilMuannats, bab) {
        val cleanFail = if (bab == 5) "-" else fail
        val cleanSifat = if (bab == 5) {
            if (sifatMusyabbahah.isNullOrBlank() || sifatMusyabbahah == "-") fail else sifatMusyabbahah
        } else {
            if (sifatMusyabbahah.isNullOrBlank()) "-" else sifatMusyabbahah
        }
        val cleanMaful = if (bab == 5) "-" else maful
        mutableListOf(
            Triple("Fi'il Madhi", madhi, "Masa Lampau (Telah)"),
            Triple("Fi'il Mudhari", mudhari, "Masa Sekarang/Akan"),
            Triple("Masdar", masdar, "Kata Benda (Gerund)"),
            Triple("Isim Fa'il", cleanFail, "Subjek (Pelaku)"),
            Triple("Isim Musyabbahah", cleanSifat, "Sifat Karakter Menetap"),
            Triple("Isim Maf'ul", cleanMaful, "Objek (Penderita)"),
            Triple("Fi'il Amr", amr, "Kata Kerja Perintah"),
            Triple("Fi'il Nahy", nahy, "Kata Kerja Larangan"),
            Triple("Isim Zaman", zaman, "Keterangan Waktu"),
            Triple("Isim Makan", makan, "Keterangan Tempat"),
            Triple("Isim Alat", alah ?: "-", "Nama Alat / Instrumen")
        ).apply {
            if (!isimTasghir.isNullOrBlank() && isimTasghir != "-") {
                add(Triple("Isim Tasghir", isimTasghir, "Kata Pengecil (Diminutive)"))
            }
            if (!isimTafdhilMudzakkar.isNullOrBlank() && isimTafdhilMudzakkar != "-") {
                add(Triple("Isim Tafdhil Lk", isimTafdhilMudzakkar, "Komparatif/Superlatif Lk"))
            }
            if (!isimTafdhilMuannats.isNullOrBlank() && isimTafdhilMuannats != "-") {
                add(Triple("Isim Tafdhil Pr", isimTafdhilMuannats, "Komparatif/Superlatif Pr"))
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Table Header Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Bentuk Kata",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.weight(1.3f)
            )
            Text(
                text = "Wazan",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "Lafadz Sharaf",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                textAlign = TextAlign.Right,
                modifier = Modifier.weight(1.5f)
            )
        }

        // Body Rows
        items.forEachIndexed { index, (label, word, desc) ->
            val isEven = index % 2 == 0
            val wazan = getWazanForForm(bab, label, word)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isEven) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                    )
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Label & Description
                Column(modifier = Modifier.weight(1.3f)) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = desc,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                // Wazan
                Text(
                    text = wazan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )

                // Arabic Word
                Text(
                    text = word,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.weight(1.5f)
                )
            }
            if (index < items.size - 1) {
                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            }
        }
    }
}
