package com.example

import com.example.data.api.GeminiApiClient
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testGeminiApi() = runBlocking {
    try {
      println("Initiating Gemini API analysis...")
      val result = GeminiApiClient.analyzeVerbRoot("فتح")
      println("Gemini API succeeded! Root: ${result.root}, Meaning: ${result.meaning}")
    } catch (e: Exception) {
      System.err.println("Gemini API failed with exception:")
      e.printStackTrace()
    }
  }
}
