#!/bin/bash
echo "==================================================="
echo "    MEMBUKA APLIKASI SHOROF MULTIFUNGSI (LOKAL)"
echo "==================================================="
if command -v python3 &>/dev/null; then
    echo "Menjalankan python3 local server di pelabuhan 8000..."
    open "http://localhost:8000" || xdg-open "http://localhost:8000"
    python3 -m http.server 8000
elif command -v python &>/dev/null; then
    echo "Menjalankan python local server di pelabuhan 8000..."
    open "http://localhost:8000" || xdg-open "http://localhost:8000"
    python -m http.server 8000
else
    echo "Membuka langsung index.html..."
    open index.html || xdg-open index.html
fi
