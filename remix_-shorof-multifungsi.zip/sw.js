const CACHE_NAME = 'shorof-multifungsi-v3';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './app/src/main/res/drawable/app_logo_gold_1780693244334.png',
  './app/src/main/res/drawable/sharaf_banner_1780682140853.png'
];

// Tahap instalasi: langsung paksa aktif tanpa menunggu tab lain ditutup
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS).catch(err => {
        console.warn('Gagal mem-cache beberapa aset utama saat instalasi:', err);
      });
    })
  );
});

// Tahap aktivasi: hapus cache usang dan ambil alih klien dengan segera
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('Menghapus cache service worker lawas:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => {
      return self.clients.claim(); // Ambil alih klien agar update langsung sinkron
    })
  );
});

// Penanganan permintaan fetch (strategi gabungan pintar)
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Bypass/jangan cache file versi (version.json) agar selalu live
  if (url.pathname.includes('version.json')) {
    event.respondWith(fetch(event.request));
    return;
  }
  
  // 1. Strategi NETWORK-FIRST untuk file utama (index.html, navigasi, document)
  // Ini memastikan file utama selalu paling baru, tapi aman dibuka saat offline (dari cache).
  if (
    event.request.mode === 'navigate' || 
    url.pathname === '/' || 
    url.pathname.endsWith('index.html') || 
    url.pathname.endsWith('.html')
  ) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // Fallback ke cache jika offline
          return caches.match(event.request);
        })
    );
  } else {
    // 2. Strategi STALE-WHILE-REVALIDATE untuk aset statis pendukung (gambar, JSON, manifest, dsb.)
    // Muat langsung dari cache secara instan, namun mutakhirkan cache di latar belakang jika online.
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        const fetchPromise = fetch(event.request).then((networkResponse) => {
          if (networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        }).catch(() => {
          // Abaikan jika network sedang offline
        });
        
        return cachedResponse || fetchPromise;
      })
    );
  }
});
