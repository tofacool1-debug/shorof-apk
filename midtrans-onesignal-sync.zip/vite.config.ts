import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react()],
    resolve: {
      alias: {
        '@/components': path.resolve(__dirname, './Folder baru/components'),
        '@/lib': path.resolve(__dirname, './Folder baru/lib'),
        '@/utils': path.resolve(__dirname, './Folder baru/utils'),
        '@/context': path.resolve(__dirname, './Folder baru/context'),
        '@/types': path.resolve(__dirname, './Folder baru/type/index.ts'),
        '@/data': path.resolve(__dirname, './Folder baru/data'),
        '@/constants': path.resolve(__dirname, './Folder baru/contants'),
        '@/contants': path.resolve(__dirname, './Folder baru/contants'),
        '@': path.resolve(__dirname, './Folder baru'),
        '@expo/vector-icons/Ionicons': path.resolve(__dirname, './src/mockIcons.tsx'),
        '@expo/vector-icons': path.resolve(__dirname, './src/mockIcons.tsx'),
        'react-native/Libraries/Utilities/codegenNativeComponent': path.resolve(__dirname, './src/mockCodegen.js'),
        'react-native-web/Libraries/Utilities/codegenNativeComponent': path.resolve(__dirname, './src/mockCodegen.js'),
        'react-native': 'react-native-web',
        'expo-modules-core': path.resolve(__dirname, './src/mockExpo.js'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
